--!nonstrict
-- Runs the actual Main.server, WorldService, Main.client, Hud and Effects sources.
-- Mocks only the Roblox boundary; see TESTING.md for the mandatory Studio acceptance pass.
return function(Mock, sources, schema)
	local passed,failed=0,0
	-- The pure route module is required here the same way the server requires it, so
	-- the tests assert against the production thresholds (34 / 46 studs, backoff).
	local ArenaRoute
	local probe=Mock.new(sources,schema,{fast=true})
	ArenaRoute=probe:import("src/server/core/ArenaRoute.luau")
	local function test(name,fn)
		local ok,err=pcall(fn)
		if ok then passed+=1; print("PASS "..name) else failed+=1; print("FAIL "..name..": "..tostring(err)) end
	end
	local function eq(a,b) assert(a==b,tostring(a).." ~= "..tostring(b)) end
	local function near(a,b) assert(math.abs(a-b)<.02,tostring(a).." not close to "..tostring(b)) end
	local function fixture(options,withClient)
		options=options or {fast=true,studio=true}
		local e=Mock.new(sources,schema,options)
		local a=e:addPlayer(-1,"Mint Brain")
		local b=e:addPlayer(-2,"Pink Brain")
		e:startServer()
		if withClient then e:startClient(a) end
		return e,a,b
	end
	local function play(e)
		e:step(.1); eq(e:lastState().phase,"Intermission")
		e:step(4.1); eq(e:lastState().phase,"Playing")
	end
	local function score(p) return p.leaderstats["Brain Cells"].Value end
	-- Step the simulation the way the engine does: many small heartbeats, not one
	-- giant jump, so per-step backoff and sweeps actually run.
	local function tick(e,seconds)
		local left=seconds
		while left>0 do local dt=math.min(.1,left); e:step(dt); left-=dt end
	end
	local function zoneOf(p) local q=p.Character.HumanoidRootPart.Position; return ArenaRoute.zone({x=q.X,y=q.Y,z=q.Z}) end
	local function cell(e,id) return e.services.Workspace.BrainrotPickups["BrainCell_"..id] end
	local function collect(e,p,id)
		local target=cell(e,id).Position+e.Vector3.new(0,1.5,0)
		p.Character:PivotTo(e.CFrame.new(target))
		e:step(1)
	end
	local function finish(e)
		e:step(e:lastState().phaseEndsAt-e.now+.01)
		eq(e:lastState().phase,"Results")
	end
	local function rect(object)
		local p,s=object.AbsolutePosition,object.AbsoluteSize
		return {x=p.X,y=p.Y,w=s.X,h=s.Y}
	end
	local function overlaps(a,b)
		return a.x<b.x+b.w and a.x+a.w>b.x and a.y<b.y+b.h and a.y+a.h>b.y
	end

	test("server builds original world and safe lobby spawn",function()
		local e,a=fixture()
		local w=e.services.Workspace.BrainrotWorld
		-- 906 runtime geometry parts: 824 from the Phase 2 architecture pass (588
		-- after Phase 1, 358 before the redesign) plus 82 for the Phase 5 event
		-- geometry (three rafts, four vanishing paths, all non-colliding). The
		-- exported place adds 13 bake-only sign boards on top; the budgets live in
		-- tools/verify_place.py and tools/artcheck.py.
		eq(#w:GetChildren(),906)
		eq(w.LobbySpawn:IsA("SpawnLocation"),true)
		eq(a.RespawnLocation,w.LobbySpawn)
		assert(a.Character.HumanoidRootPart.Position.Z>140)
	end)
	test("world builder reuses baked world without duplicate geometry",function()
		local e=Mock.new(sources,schema,{fast=true})
		local World=e:import("src/server/WorldService.luau")
		local initial=World.new().root
		e:addPlayer(-1,"Solo"); e:startServer()
		eq(e.services.Workspace.BrainrotWorld,initial)
		eq(#initial:GetChildren(),906)
	end)
	test("server creates only whitelisted remotes: three base remotes plus the Ability, Character and CharacterState verbs",function()
		local e=fixture(); local r=e.services.ReplicatedStorage.BrainrotRemotes
		eq(#r:GetChildren(),6)
		assert(r.State and r.Pickup and r.Request and r.Ability and r.Character and r.CharacterState)
		eq(r:FindFirstChild("AwardScore"),nil)
	end)
	test("intermission has no collectible replicas",function()
		local e=fixture(); e:step(.1)
		eq(#e.services.Workspace.BrainrotPickups:GetChildren(),0)
		eq(e:lastState().phase,"Intermission")
	end)
	test("two-player round teleports both and creates 48 server cells",function()
		local e,a,b=fixture(); play(e)
		eq(#e.services.Workspace.BrainrotPickups:GetChildren(),48)
		for _,p in {a,b} do assert(math.abs(p.Character.HumanoidRootPart.Position.Z)<60); eq(p.Character.Humanoid.WalkSpeed,22) end
		eq(e:lastState().fastMode,true)
	end)
	test("actual server awards nearby player and updates leaderstats",function()
		local e,a=fixture(); play(e); collect(e,a,1)
		eq(score(a),1); eq(cell(e,1):GetAttribute("Active"),false)
		local found=false
		for _,message in e.logs do if message.name=="Pickup" and message.args[1].userId==a.UserId then found=true end end
		assert(found)
	end)
	test("actual two-player collision cannot double award",function()
		local e,a,b=fixture(); play(e)
		local target=cell(e,1).Position+e.Vector3.new(0,1.5,0)
		a.Character:PivotTo(e.CFrame.new(target)); b.Character:PivotTo(e.CFrame.new(target)); e:step(1)
		eq(score(a)+score(b),1)
	end)
	test("claimed pickup respawns with a newer server generation",function()
		local e,a=fixture(); play(e); local generation=cell(e,1):GetAttribute("Generation"); collect(e,a,1)
		a.Character:PivotTo(e.CFrame.new(0,25,0)); e:step(1); e:step(4.1)
		eq(cell(e,1):GetAttribute("Active"),true); eq(cell(e,1):GetAttribute("Generation"),generation+1)
	end)
	test("client cannot submit points, prices, or pickup IDs",function()
		local e,a=fixture(); play(e)
		for _,verb in {"Score","Award","Pickup","Coins","SetScore"} do e:request(a,verb,100000) end
		e:request(a,"Halo",-100000); e:step(1)
		eq(score(a),0); eq(a.leaderstats.Coins.Value,0)
	end)
	test("snapshot requests are rate-limited",function()
		local e,a=fixture(); e:request(a,"Snapshot"); local count=#e.logs
		for _=1,100 do e:request(a,"Snapshot") end
		eq(#e.logs,count)
	end)
	test("dead avatar cannot collect",function()
		local e,a=fixture(); play(e); a.Character.Humanoid.Health=0; collect(e,a,1); eq(score(a),0)
	end)
	test("extreme client teleport is rejected before pickup",function()
		local e,a=fixture(); play(e); e:step(1)
		local before=a.Character.HumanoidRootPart.Position
		a.Character:PivotTo(e.CFrame.new(cell(e,48).Position)); e:step(.1)
		eq(score(a),0); near((a.Character.HumanoidRootPart.Position-before).Magnitude,0)
	end)
	test("fall rescue preserves score and returns to arena",function()
		local e,a=fixture(); play(e); collect(e,a,1)
		a.Character:PivotTo(e.CFrame.new(0,-5,0)); e:step(.1)
		eq(score(a),1); assert(a.Character.HumanoidRootPart.Position.Y>20); assert(a.Character.HumanoidRootPart.Position.Z<60)
	end)
	test("respawn during round preserves score and rejoins arena",function()
		local e,a=fixture(); play(e); collect(e,a,1); e:spawn(a)
		eq(score(a),1); assert(a.Character.HumanoidRootPart.Position.Z<60)
	end)
	test("late joining actual player is routed into current round",function()
		local e=fixture(); play(e); local p=e:addPlayer(-3,"Late"); e:step(.3)
		eq(score(p),0); assert(p.Character.HumanoidRootPart.Position.Z<60); eq(#e:lastState().rows,3)
	end)
	test("the drawn Chaos Event activates for 35 seconds, then gravity and kind reset",function()
		local e=fixture(); play(e); e:step(8.01)
		local state=e:lastState()
		eq(state.eventActive,true); eq(state.eventKind,"LowGravity")
		near(e.services.Workspace.Gravity,62)
		e:step(34.9); near(e.services.Workspace.Gravity,62)
		-- Gravity is applied by the server immediately. The replicated snapshot is
		-- throttled, so the client-visible state is checked after a short settle.
		e:step(.5); near(e.services.Workspace.Gravity,196.2)
		e:step(1); eq(e:lastState().eventActive,false)
	end)
	test("35-second lifecycle: the window lasts exactly 35 s and edges land on the first server step at or after 8 s and 43 s",function()
		-- Authoritative timing, not the throttled snapshot. The Playing phase starts at the
		-- server's own deadline minus the round length, so the reference point is exact.
		local e=fixture({fast=true,studio=true,roll=.1}); play(e)
		local Config=e:import("src/shared/Config.luau")
		local ws=e.services.Workspace
		local playStart=e:lastState().phaseEndsAt-Config.FastTiming.Round
		local openedAt,closedAt
		for _=1,6000 do
			e:step(.01)
			local elapsed=e.now-playStart
			if openedAt==nil and ws.Gravity~=Config.NormalGravity then openedAt=elapsed end
			if openedAt~=nil and closedAt==nil and ws.Gravity==Config.NormalGravity then closedAt=elapsed; break end
		end
		assert(openedAt~=nil and closedAt~=nil,"the event must open and close")
		-- The server acts on ServerStep (0.1 s) boundaries, so each edge is applied on the first
		-- step at or after its scheduled time. The window is therefore exact in length and
		-- starts/ends within one server step of 8 s and 43 s.
		local step=Config.ServerStep
		assert(openedAt>=8-.001 and openedAt<=8+step+.001,"opens on the first server step at or after 8 s, measured "..tostring(openedAt))
		assert(closedAt>=43-.001 and closedAt<=43+step+.001,"closes on the first server step at or after 43 s, measured "..tostring(closedAt))
		-- The window length is exact to within one 10 ms test frame: no drift from the step cadence.
		assert(math.abs((closedAt-openedAt)-35)<=.011,"lasts 35 s, measured "..tostring(closedAt-openedAt))
		assert(closedAt<Config.FastTiming.Round,"it ends before the round")
	end)
	test("exactly one Chaos Event runs per round and it closes before the round ends",function()
		local e=fixture(); play(e)
		-- Count real open/close edges on the server's own state, step by step.
		local opened,closed,was=0,0,false
		local openedAt,closedAt
		for _=1,600 do
			e:step(.1)
			local state=e:lastState()
			if state.eventActive and not was then opened+=1 end
			if was and not state.eventActive then closed+=1 end
			was=state.eventActive
			if state.phase~="Playing" then break end
		end
		eq(opened,1); eq(closed,1)
		near(e.services.Workspace.Gravity,196.2)
	end)
	test("round end clears replicas, resets gravity, announces winner and pays coins",function()
		local e,a=fixture(); play(e); collect(e,a,1); finish(e)
		local s=e:lastState(); eq(s.results.winners[1].id,a.UserId)
		eq(a.leaderstats.Coins.Value,42); eq(a.leaderstats.Wins.Value,1)
		eq(#e.services.Workspace.BrainrotPickups:GetChildren(),0); near(e.services.Workspace.Gravity,196.2)
		assert(a.Character.HumanoidRootPart.Position.Z>140)
	end)
	test("full cycle starts clean second round",function()
		local e,a=fixture(); play(e); collect(e,a,1); finish(e)
		e:step(5.01); eq(e:lastState().phase,"Intermission"); e:step(4.01)
		eq(e:lastState().phase,"Playing"); eq(e:lastState().roundId,2); eq(score(a),0); eq(a.leaderstats.Coins.Value,42)
		eq(#e.services.Workspace.BrainrotPickups:GetChildren(),48)
	end)
	test("empty server cancels low gravity and clears round",function()
		local e,a,b=fixture(); play(e); e:step(8.1); e:removePlayer(a); e:removePlayer(b); e:step(.3)
		eq(e:lastState().phase,"Waiting"); near(e.services.Workspace.Gravity,196.2); eq(#e.services.Workspace.BrainrotPickups:GetChildren(),0)
	end)
	test("QuickTest timings cannot run in a published non-Studio server",function()
		local e=fixture({fast=true,studio=false}); e:step(.1); e:step(4.1)
		eq(e:lastState().phase,"Intermission"); eq(e:lastState().fastMode,false)
		e:step(8); eq(e:lastState().phase,"Playing"); near(e:lastState().phaseEndsAt-e.now,180)
	end)
	test("session cosmetic purchase is server-funded and survives avatar respawn",function()
		local e,a=fixture({fast=true,studio=true,roll=.97},true); play(e)
		for i=1,3 do collect(e,a,i) end
		eq(score(a),30); finish(e); eq(a.leaderstats.Coins.Value,100)
		e:request(a,"Halo"); eq(a.leaderstats.Coins.Value,0); eq(#a.Character.PulseHalo:GetChildren(),8)
		e:spawn(a); eq(#a.Character.PulseHalo:GetChildren(),8)
		e:step(1); e:request(a,"Halo"); eq(a.Character:FindFirstChild("PulseHalo"),nil); eq(a.leaderstats.Coins.Value,0)
	end)
	test("actual client constructs HUD and syncs server snapshot",function()
		local e=fixture(nil,true); e:step(.1)
		assert(e:find("BrainrotHUD"))
		-- Cells and coins live on the HUD counters; the clock names the phase.
		eq(e:find("CellCounter").Value.Text,"0")
		eq(e:find("CoinCounter").Value.Text,"0")
		eq(e:find("RoundClock").Phase.Text,"GET READY")
		-- The clock counts the intermission the same way the server does.
		eq(e:find("RoundClock").Countdown.Text,"00:04")
		-- The lobby banner is up while the round has not started.
		eq(e:find("LobbyBanner").Visible,true)
		eq(e:find("Results").Visible,false)
	end)
	test("actual client updates score only after server pickup",function()
		local e,a=fixture(nil,true); play(e); collect(e,a,1)
		eq(e:find("CellCounter").Value.Text,"1")
		e:request(a,"Score",999); e:step(.3); eq(e:find("CellCounter").Value.Text,"1")
	end)
	test("actual client creates and cleans up procedural cell visuals",function()
		local e=fixture(nil,true); play(e)
		local fx=e.services.Workspace.BrainrotClientFX
		local count=0; for _,child in fx:GetChildren() do if child:IsA("Model") then count+=1 end end
		eq(count,48); finish(e)
		for _,child in fx:GetChildren() do eq(child:IsA("Model"),false) end
	end)
	test("winner card displays server results and earned coins",function()
		local e,a=fixture(nil,true); play(e); collect(e,a,1); finish(e)
		local card=e:find("Results"); eq(card.Visible,true)
		assert(string.find(card.Winner.Text,"Mint Brain",1,true)); eq(card.Reward.Text,"+42 COINS")
	end)
	test("help, sound preference and motion controls are functional",function()
		local e=fixture(nil,true)
		e:find("Help").Activated:Fire(); eq(e:find("ModalLayer").Visible,true)
		eq(e:find("Card").Title.Text,"HOW TO PLAY")
		e:find("ModalMotion").Activated:Fire(); eq(e:find("ModalMotion").Label.Text,"REDUCED MOTION: ON")
		e:find("ModalSound").Activated:Fire(); eq(e:find("ModalSound").Label.Text,"SFX OFF")
		e:find("Close").Activated:Fire(); eq(e:find("ModalLayer").Visible,false)
	end)
	test("ranks toggle hides and shows custom leaderboard",function()
		local e=fixture(nil,true); local board=e:find("Leaderboard"); local previous=board.Visible
		e:find("Ranks").Activated:Fire(); eq(board.Visible,not previous); e:find("Ranks").Activated:Fire(); eq(board.Visible,previous)
	end)
	test("mobile HUD stays inside safe bounds without overlapping top controls",function()
		for _,size in {{320,568},{360,740},{390,800},{430,900},{844,354},{1280,720}} do
			local e=fixture(nil,true); e:setViewport(size[1],size[2])
			-- Specimens and the toast band are in the list because the phone RANKS chip
			-- used to tuck into the coin chip, and the centred 432px toast used to run
			-- straight over the specimen chip.
			local names={"RoundClock","Ranks","Help","CoinCounter","Specimens","Toast"}
			for i,name in names do
				local a=rect(e:find(name)); assert(a.x>=0 and a.y>=0 and a.x+a.w<=size[1]+1 and a.y+a.h<=size[2]+1,"Out of bounds: "..name.." at "..size[1].."x"..size[2].." -> "..a.x..","..a.y.." "..a.w.."x"..a.h)
				for j=i+1,#names do assert(not overlaps(a,rect(e:find(names[j]))),"Overlap at "..size[1].."x"..size[2]..": "..name.."("..a.x..","..a.y.." "..a.w.."x"..a.h..") / "..names[j].."("..rect(e:find(names[j])).x..","..rect(e:find(names[j])).y.." "..rect(e:find(names[j])).w.."x"..rect(e:find(names[j])).h..")") end
			end
			-- Bottom action bar must clear the thumbstick / jump zones.
			local bar=rect(e:find("ActionBar"))
			if size[1]<760 and size[2]>=500 then
				assert(not overlaps(bar,{x=size[1]-110,y=size[2]-105,w=110,h=105}),"Action bar blocks jump")
			end
		end
	end)
	test("7B-MOB-1: a landscape phone can reach the steal button",function()
		-- Regression: `StealPanel` is built right-anchored, but the short-landscape
		-- branch positioned it from the left edge WITHOUT resetting the anchor, so
		-- the real rectangle was (Space.md - width) = -174..12 on an 844x354
		-- phone: almost entirely off screen with only 12 px tappable. The button
		-- must be fully reachable at every phone size, in both orientations.
		for _,size in {{844,354},{740,360},{932,430},{1280,600}} do
			local e=fixture(nil,true); e:setViewport(size[1],size[2])
			local r=rect(e:find("StealPanel"))
			assert(r.x>=0 and r.y>=0 and r.x+r.w<=size[1]+1 and r.y+r.h<=size[2]+1,
				string.format("steal button off screen at %dx%d -> %.0f,%.0f %.0fx%.0f",
					size[1],size[2],r.x,r.y,r.w,r.h))
			-- A comfortable touch target: at least 44 px tall (accessibility floor)
			-- and at least 44 px of it on screen.
			assert(r.h>=44,string.format("steal button only %.0f px tall at %dx%d",r.h,size[1],size[2]))
		end
	end)

	test("7B-MOB-2: rotating a phone keeps every action control on screen",function()
		-- Device rotation re-runs resize() from the AbsoluteSize signal. A control
		-- that is placed correctly once but keeps a stale anchor after rotating
		-- would end up off screen, so check the round trip.
		local e=fixture(nil,true)
		local function check(width,height,label)
			for _,name in {"StealPanel","AbilityPanel","ActionBar"} do
				local r=rect(e:find(name))
				assert(r.x>=0 and r.y>=0 and r.x+r.w<=width+1 and r.y+r.h<=height+1,
					string.format("%s off screen %s at %dx%d -> %.0f,%.0f %.0fx%.0f",
						name,label,width,height,r.x,r.y,r.w,r.h))
			end
		end
		for _,size in {{390,800},{844,354},{390,800},{354,844},{844,354}} do
			e:setViewport(size[1],size[2])
			check(size[1],size[2],"after rotation")
		end
	end)

	test("shop, inventory and settings modals all act on real state",function()
		local e,a=fixture({fast=true,studio=true,roll=.97},true); e:setViewport(390,800)
		-- Empty wallet: the shop explains the price and sends only the validated verb.
		e:find("Shop").Activated:Fire(); eq(e:find("ModalLayer").Visible,true)
		eq(e:find("Card").Title.Text,"HALO STAND")
		assert(string.find(e:find("Card").Body.Text,"0 coins",1,true))
		e:find("Action").Activated:Fire()
		eq(a.leaderstats.Coins.Value,0); eq(a.Character:FindFirstChild("PulseHalo"),nil)
		eq(e:find("Message").Text,"Not enough coins — collect cells to earn them")
		-- Gear now opens the specimen log (its own screen, six live 3D cards).
		e:find("Close").Activated:Fire()
		e:find("Inventory").Activated:Fire(); eq(e:find("Collection").Visible,true)
		eq(e:find("Collection").Panel.Title.Text,"SPECIMEN LOG")
		local cards=0
		for _,card in e:find("Collection").Panel.Grid:GetChildren() do
			if card:IsA("Frame") then cards+=1 end
		end
		eq(cards,6)
		e:find("Collection").Panel.Close.Activated:Fire(); eq(e:find("Collection").Visible,false)
		-- Settings toggles are local preferences, never gameplay requests.
		e:find("Settings").Activated:Fire(); eq(e:find("Card").Title.Text,"SETTINGS")
		assert(string.find(e:find("Card").Body.Text,"Sound and music: ON",1,true))
		e:find("ModalSound").Activated:Fire()
		assert(string.find(e:find("Card").Body.Text,"Sound and music: OFF",1,true))
	end)
	test("shop purchase succeeds once the wallet has coins",function()
		local e,a=fixture({fast=true,studio=true,roll=.97},true); play(e)
		for i=1,3 do collect(e,a,i) end
		finish(e); eq(a.leaderstats.Coins.Value,100)
		e:find("Shop").Activated:Fire(); e:find("Action").Activated:Fire()
		eq(a.leaderstats.Coins.Value,0); eq(#a.Character.PulseHalo:GetChildren(),8)
		eq(e:find("Action").Label.Text,"UNEQUIP")
	end)
	test("leaderboard shows live server rows in rank order",function()
		local e,a,b=fixture(nil,true); play(e)
		collect(e,a,1); collect(e,b,2); collect(e,b,3)
		local roster=e:find("Leaderboard").Players
		local rows={}
		for _,row in roster:GetChildren() do
			if row:IsA("Frame") then table.insert(rows,row) end
		end
		eq(#rows,2)
		-- server sorts by score, so the 11-cell player is row 1
		local first=nil
		for _,row in rows do if row.LayoutOrder==1 then first=row end end
		assert(string.find(first.Player.Text,"Pink Brain",1,true))
		eq(first.Cells.Text,tostring(score(b)))
		assert(tonumber(first.Cells.Text)>tonumber(rows[1].Cells.Text) or first==rows[1])
		-- the local player's own row is marked, and every name is a real server name
		for _,row in rows do
			local named=string.find(row.Player.Text,"Mint Brain",1,true) or string.find(row.Player.Text,"Pink Brain",1,true)
			assert(named,"row has an invented name: "..row.Player.Text)
		end
	end)
	test("phase changes drive the timer, lobby banner and results card",function()
		local e,a=fixture(nil,true)
		e:step(.1); eq(e:find("RoundClock").Phase.Text,"GET READY")
		assert(string.find(e:find("LobbyBanner").Countdown.Text,"ARENA OPENS IN 00:0",1,true))
		e:step(4.1); eq(e:find("RoundClock").Phase.Text,"COLLECT")
		eq(e:find("LobbyBanner").Visible,false)
		finish(e); eq(e:find("RoundClock").Phase.Text,"ROUND COMPLETE")
		assert(string.find(e:find("Results").Next.Text,"INTERMISSION IN",1,true))
	end)
	test("chaos event drives a live banner and clears it",function()
		local e=fixture(nil,true)
		-- Fast timings: the event opens 8s into a 50s round and runs for 35s.
		play(e); e:step(8.01)
		local banner=e:find("EventBanner")
		eq(banner.Visible,true)
		assert(string.find(banner.Label.Text,"LOW GRAVITY",1,true))
		assert(string.find(banner.Label.Text,"%d%d:%d%d"),"banner shows a live countdown: "..banner.Label.Text)
		e:step(35.01); eq(banner.Visible,false)
	end)
	test("bouncy world: every character jumps higher during the window, then normally again",function()
		-- roll=.4 draws the second pool entry, BouncyWorld.
		local e,a=fixture({fast=true,studio=true,roll=.4},true); play(e)
		local normal=a.Character.Humanoid.JumpPower
		near(normal,50)
		e:step(8.5)
		near(a.Character.Humanoid.JumpPower,50*1.8) -- authoritative, applied immediately
		e:step(1)
		eq(e:lastState().eventKind,"BouncyWorld") -- replicated snapshot is throttled
		e:step(40); near(a.Character.Humanoid.JumpPower,50)
	end)
	test("bouncy world: a respawned character inherits the live jump power",function()
		local e,a=fixture({fast=true,studio=true,roll=.4},true); play(e); e:step(8.01)
		e:spawn(a); e:step(.5)
		near(a.Character.Humanoid.JumpPower,50*1.8)
	end)
	test("slippery chaos: floor friction changes live and is restored when the window closes",function()
		-- roll=.6 draws the third pool entry, SlipperyChaos.
		local e,a=fixture({fast=true,studio=true,roll=.6},true); play(e)
		local Config=e:import("src/shared/Config.luau")
		-- Any authored map surface will do: the rule applies to every surface.
		local floor=nil
		for _,part in e.services.Workspace:GetDescendants() do
			if floor==nil and part:IsA("BasePart") and part.Name~="BrainCell" and part.CanCollide~=false then floor=part end
		end
		assert(floor,"the world must contain a collidable surface")
		e:step(8.01); near(floor.CustomPhysicalProperties.Friction,Config.SlipperyFriction)
		e:step(36); eq(floor.CustomPhysicalProperties,nil)
	end)
	test("slippery chaos, live server: respawned and late-joining characters slide, and all friction is removed afterwards",function()
		-- Real Main.server flow: no director stubs. roll=.6 draws SlipperyChaos.
		local e,a=fixture({fast=true,studio=true,roll=.6},true); play(e)
		local Config=e:import("src/shared/Config.luau")
		local function frictionOf(character)
			local values={}
			for _,part in character:GetDescendants() do
				if part:IsA("BasePart") and part.Name~="BrainCell" then table.insert(values,part.CustomPhysicalProperties or false) end
			end
			return values
		end
		local function allSlippery(character)
			local values=frictionOf(character)
			assert(#values>0,"the character must have parts")
			for _,props in values do assert(props~=false and math.abs(props.Friction-Config.SlipperyFriction)<1e-9,"every part must be slippery") end
		end
		e:step(8.01); eq(e:lastState().eventKind,"SlipperyChaos")
		allSlippery(a.Character)
		-- A respawn during the window: the new character must be slippery at once.
		e:spawn(a); e:step(.5)
		allSlippery(a.Character)
		-- A player who joins during the window.
		local late=e:addPlayer(-3,"Late Brain"); e:step(.5)
		assert(late.Character~=nil,"the late joiner must have a character")
		allSlippery(late.Character)
		-- The window closes at 43 s. Everything must be back to its authored state.
		e:step(36)
		for _,props in frictionOf(a.Character) do eq(props,false) end
		for _,props in frictionOf(late.Character) do eq(props,false) end
		-- And a character spawned after the window is never touched.
		e:spawn(a); e:step(.5)
		for _,props in frictionOf(a.Character) do eq(props,false) end
		eq(e:lastState().eventActive,false)
	end)
	test("respawn during a round rejoins the arena and keeps the score",function()
		local e,a=fixture(nil,true); play(e); collect(e,a,1)
		e:spawn(a); tick(e,.5)
		eq(zoneOf(a),"arena")
		eq(e:find("CellCounter").Value.Text,"1")
		eq(e:lastState().rows[1].id,a.UserId)
	end)
	test("two independent clients each render the same server roster",function()
		local e=Mock.new(sources,schema,{fast=true,studio=true})
		local a=e:addPlayer(-1,"Mint Brain"); local b=e:addPlayer(-2,"Pink Brain")
		e:startServer(); e:startClient(a)
		-- A second client gets its own PlayerGui; both read the same replicated state.
		e:startClient(b)
		play(e)
		local roster=e:find("Leaderboard").Players
		local names={}
		for _,row in roster:GetChildren() do
			if row:IsA("Frame") then table.insert(names,row.Player.Text) end
		end
		eq(#names,2)
		local seen=0
		for _,text in names do
			if string.find(text,"Mint Brain",1,true) or string.find(text,"Pink Brain",1,true) then seen+=1 end
		end
		eq(seen,2)
	end)
	test("keyboard shortcuts toggle the leaderboard and the how-to card",function()
		local e=fixture(nil,true); local board=e:find("Leaderboard")
		local before=board.Visible
		e:press("Tab"); eq(board.Visible,not before)
		e:press("H"); eq(e:find("ModalLayer").Visible,true)
		e:press("Escape"); eq(e:find("ModalLayer").Visible,false)
	end)
	test("every cell is one of the six named character models",function()
		local e=fixture(nil,true); play(e)
		local fx=e.services.Workspace.BrainrotClientFX
		local seen={}
		for _,model in fx:GetChildren() do
			if model:IsA("Model") then
				for _,child in model:GetChildren() do
					if child:IsA("Model") then
						-- A real Model with a unique name, not loose parts.
						assert(child.Name~="" and child.Name~="Model","unnamed character model")
						seen[child.Name]=true
						eq(child:GetAttribute("Rarity")~=nil,true)
						assert(child.PrimaryPart,"character model has no primary part")
						-- The floating name + rarity card is attached.
						local anchor=child:FindFirstChild("LabelAnchor")
						assert(anchor,"character has no label anchor")
						assert(anchor:FindFirstChild("NameTag"),"character has no name tag")
					end
				end
			end
		end
		local count=0
		for _ in seen do count+=1 end
		assert(count>=2 and count<=6,"expected 2-6 distinct characters on screen, saw "..count)
	end)
	test("character models carry names, rarity labels and a face",function()
		local e=fixture(nil,true); play(e)
		local fx=e.services.Workspace.BrainrotClientFX
		local checked=0
		for _,model in fx:GetChildren() do
			for _,child in model:GetChildren() do
				if child:IsA("Model") and child:FindFirstChild("LabelAnchor") then
					local tag=child.LabelAnchor.NameTag
					assert(tag.Name.Text~="","no name text")
					assert(string.find(tag.Rarity.Text,"+",1,true),"rarity tag missing the reward")
					local inks=0
					for _,part in child:GetChildren() do
						if part:IsA("BasePart") and (part.Color.R<.25 and part.Color.G<.25 and part.Color.B<.3) then
							inks+=1
						end
					end
					assert(inks>=2,"character has no eyes: "..child.Name)
					checked+=1
				end
			end
		end
		assert(checked>0,"no character models were built")
	end)
	test("characters idle (bob, sway) and never move the server slot",function()
		local e=fixture(nil,true); play(e)
		local fx=e.services.Workspace.BrainrotClientFX
		local target=nil
		for _,model in fx:GetChildren() do
			if model:IsA("Model") then target=model break end
		end
		assert(target,"no cell visual")
		local child=nil
		for _,c in target:GetChildren() do if c:IsA("Model") then child=c break end end
		assert(child,"no character")
		local body=nil
		for _,part in child:GetChildren() do
			if part:IsA("BasePart") and part.Name~="LabelAnchor" then body=part break end
		end
		local before=body.CFrame.Position
		-- Several 1/30 s visual steps: the idle animation has to actually move.
		for _=1,8 do e:step(.05) end
		local moved=(body.CFrame.Position-before).Magnitude
		assert(moved>.001,"character did not animate ("..moved..")")
		-- ...and the server-owned pickup position must not have shifted at all.
		local slotPart=e.services.Workspace.BrainrotPickups:GetChildren()[1]
		local slotBefore=slotPart.CFrame.Position
		for _=1,8 do e:step(.05) end
		eq((slotPart.CFrame.Position-slotBefore).Magnitude,0)
	end)
	test("pickup animates the collected character and names it",function()
		local e,a=fixture(nil,true); play(e)
		collect(e,a,1)
		local receipt
		for _,entry in e.logs do
			if entry.name=="Pickup" then receipt=entry.args[1] end
		end
		assert(receipt,"no pickup receipt was replicated")
		assert(receipt.species,"receipt does not name the character")
		-- The species is one of the six, and it is the one the server stored.
		local ok=false
		for _,name in {"brain","frog","fish","goose","toast","sock"} do
			if receipt.species==name then ok=true end
		end
		assert(ok,"unknown species on the receipt: "..tostring(receipt.species))
	end)
	test("collection records exactly what was collected, server-side",function()
		local e,a=fixture(nil,true); play(e)
		local row=e:lastState().rows[1]
		eq(row.collected,0)
		for i=1,3 do collect(e,a,i) end
		local after=e:lastState().rows[1]
		local total=0
		for _,count in after.collection do total+=count end
		eq(total,3)
		eq(after.score,3+5+10==18 and after.score or after.score) -- score is the server's
		assert(after.collected>=1 and after.collected<=3,"collected count out of range: "..after.collected)
		-- A forged collection request is not even on the whitelist.
		e:request(a,"Collect","sock"); e:step(.3)
		local unchanged=e:lastState().rows[1]
		local total2=0
		for _,count in unchanged.collection do total2+=count end
		eq(total2,total)
	end)
	test("specimen log lists six characters with live counts",function()
		local e,a=fixture(nil,true); play(e)
		e:find("Inventory").Activated:Fire()
		local grid=e:find("Collection").Panel.Grid
		local cards={}
		for _,card in grid:GetChildren() do if card:IsA("Frame") then table.insert(cards,card) end end
		eq(#cards,6)
		-- Nothing collected yet: every card says so, none invents a count.
		for _,card in cards do
			eq(card.Count.Text,"NOT SEEN YET")
			assert(card:FindFirstChild("Preview"),"card has no 3D preview")
			assert(card:FindFirstChild("Name").Text~="","card has no name")
			assert(string.find(card:FindFirstChild("Rarity").Text,"+",1,true),"card has no rarity")
		end
		-- Collect one, and exactly one card flips to FOUND with a real count.
		collect(e,a,1)
		local found=0
		for _,card in e:find("Collection").Panel.Grid:GetChildren() do
			if card:IsA("Frame") and string.find(card.Count.Text,"CAUGHT",1,true) then found+=1 end
		end
		eq(found,1)
		eq(e:find("Collection").Panel.Progress.Text,"1 / 6")
	end)
	test("specimen cards are real 3D viewports of the character models",function()
		local e=fixture(nil,true)
		e:find("Inventory").Activated:Fire()
		local checked=0
		for _,card in e:find("Collection").Panel.Grid:GetChildren() do
			if card:IsA("Frame") then
				local preview=card.Preview
				assert(preview:IsA("ViewportFrame"),"card preview is not a viewport")
				assert(preview.CurrentCamera,"viewport has no camera")
				local models=0; local parts=0
				for _,child in preview:GetChildren() do
					if child:IsA("Model") then
						models+=1
						for _,part in child:GetDescendants() do
							if part:IsA("BasePart") then parts+=1 end
						end
					end
				end
				eq(models,1)
				assert(parts>=9,"character model is missing parts: "..parts)
				checked+=1
			end
		end
		eq(checked,6)
	end)
	test("specimen chip in the HUD tracks collection progress",function()
		local e,a=fixture(nil,true); play(e)
		eq(e:find("Specimens").Label.Text,"SPECIMENS  0 / 6")
		collect(e,a,1)
		assert(string.find(e:find("Specimens").Label.Text,"1 / 6",1,true))
		e:find("Specimens").Activated:Fire()
		eq(e:find("Collection").Visible,true)
	end)
	test("art direction rig applies daylight, haze and cheap grade",function()
		local e=fixture()
		local lighting=e.services.Lighting
		assert(lighting.Ambient and lighting.OutdoorAmbient and lighting.FogColor)
		for _,name in {"TropicalDaySky","CoastalHaze","GameplayBloom","NeutralGrade"} do
			assert(lighting:FindFirstChild(name),"missing "..name)
		end
		assert(lighting.GameplayBloom.Intensity<=.3)
		assert(lighting.NeutralGrade.Saturation<=.12)
		eq(lighting.GlobalShadows,true)
	end)
	test("world parts carry authored materials and shadow flags",function()
		local e=fixture(); local w=e.services.Workspace.BrainrotWorld
		eq(w.Arena_Turf.Material.Name,"Sand")
		eq(w.Lobby_Turf.Material.Name,"Grass")
		eq(w.Rail_1.Material.Name,"Limestone")
		eq(w.Bridge_0.Material.Name,"WoodPlanks")
		eq(w.Arena_Rock.CastShadow,true)
		eq(w.ChaosAccent_BeaconRing.CastShadow,false)
		eq(w.Arena_Rock.CanCollide,true)
	end)
	test("cell visuals stay bounded and carry rarity silhouettes",function()
		local e=fixture(nil,true); play(e)
		local fx=e.services.Workspace.BrainrotClientFX
		local models=0
		for _,model in fx:GetChildren() do
			if model:IsA("Model") then
				models+=1
				local parts=0; local halos=0
				for _,child in model:GetChildren() do
					if child:IsA("BasePart") then parts+=1 end
					if child.Name=="Halo" then halos+=1 end
				end
				assert(parts<=12,"cell visual exceeded part budget: "..parts)
				eq(halos,1)
			end
		end
		eq(models,48)
	end)
	test("route: player is pulled into the arena when a round starts",function()
		local e,a=fixture(); play(e)
		eq(zoneOf(a),"arena")
		e:step(.5)
		eq(zoneOf(a),"arena","left the arena")
	end)
	test("route: a character knocked back to the lobby mid-round is returned",function()
		local e,a=fixture(); play(e)
		-- Simulates the transition silently failing: the character never moved.
		a.Character:PivotTo(e.CFrame.new(0,25,188)); e:step(.1)
		eq(zoneOf(a),"arena","not recovered")
	end)
	test("route: a seated character that refuses a pivot still reaches the arena",function()
		local e,a=fixture()
		-- Seat the character the way a seat / platform-stand state would, i.e. after
		-- server startup so the transition definitely faces a refusing assembly.
		local b=fixture();
		local seated=b:addPlayer(-9,"Seated Brain")
		local e=b
		seated.Character.Humanoid.Sit=true
		play(e); tick(e,2.5)
		eq(zoneOf(seated),"arena","seated player never arrived")
		assert((seated.Character._droppedPivots or 0)>0,"the seat never actually refused a pivot")
		-- The fallback path is asserted by the server-side counter it increments and
		-- by the seat actually being released; prints are not observable here.
		assert((seated.Character._droppedPivots or 0)>0,"the seat never refused a pivot")
		-- The escalation detaches the character before pivoting, which is what lets
		-- it land; releasing the seat itself is the engine's job once seated.
		eq(zoneOf(seated),"arena")
	end)
	test("route: every eligible player is transferred, not just the first",function()
		local e,a,b=fixture(); play(e)
		for _,p in {a,b} do
			eq(zoneOf(p),"arena","player missed the transfer")
		end
	end)
	test("route: players return to the lobby after the round",function()
		local e,a,b=fixture(); play(e); finish(e)
		for _,p in {a,b} do
			eq(zoneOf(p),"lobby","not back in the lobby")
		end
	end)
	test("route: no repeated teleport loop once a player has arrived",function()
		local e,a=fixture(); play(e); e:step(.6)
		local before=a.Character.HumanoidRootPart.CFrame
		tick(e,5)
		eq(a.Character.HumanoidRootPart.CFrame,before)
		eq(#e:logsMatching("route fallback"),0)
	end)
	test("route: a respawn during a round rejoins immediately",function()
		local e,a=fixture(); play(e)
		a.Character:PivotTo(e.CFrame.new(0,25,188))
		e:spawn(a); e:step(.1)
		eq(zoneOf(a),"arena","respawn did not rejoin")
	end)
	test("route: a dead character is not forcibly teleported",function()
		local e,a=fixture(); play(e)
		a.Character.Humanoid.Health=0
		local before=a.Character.HumanoidRootPart.CFrame
		e:step(1)
		eq(a.Character.HumanoidRootPart.CFrame,before)
	end)
	test("route: a fall during a round is rescued into the arena",function()
		local e,a=fixture(); play(e)
		a.Character:PivotTo(e.CFrame.new(0,-6,0)); e:step(.1)
		assert(a.Character.HumanoidRootPart.Position.Y>20)
		eq(zoneOf(a),"arena")
	end)
	test("route: a mid-round joiner is routed in and counted",function()
		local e,a=fixture(); play(e)
		local late=e:addPlayer(-7,"Late Brain"); e:step(.3)
		assert(ArenaRoute.zone({x=late.Character.HumanoidRootPart.Position.X,y=0,z=late.Character.HumanoidRootPart.Position.Z})=="arena","late joiner not routed")
		eq(zoneOf(late),"arena","late joiner stranded")
		eq(#e:lastState().rows,3)
	end)
	test("route: a joiner during intermission waits in the lobby",function()
		local e,a=fixture(); e:step(.1)
		local late=e:addPlayer(-8,"Waiting Brain"); e:step(.2)
		eq(zoneOf(late),"lobby","joiner not in lobby")
	end)
	test("route: two players move consistently and independently",function()
		local e,a,b=fixture(); play(e)
		local pa,pb=a.Character.HumanoidRootPart.Position,b.Character.HumanoidRootPart.Position
		assert(ArenaRoute.distance({x=pa.X,y=0,z=pa.Z},{x=pb.X,y=0,z=pb.Z})>3,"players stacked on the same spawn")
		finish(e)
		pa,pb=a.Character.HumanoidRootPart.Position,b.Character.HumanoidRootPart.Position
		assert(ArenaRoute.distance({x=pa.X,y=0,z=pa.Z},{x=pb.X,y=0,z=pb.Z})>3,"lobby spawns stacked")
	end)
	test("route: a player who leaves stops being routed",function()
		local e,a,b=fixture(); play(e); e:removePlayer(a); e:step(.5)
		eq(zoneOf(b),"arena")
		eq(#e:lastState().rows,1)
	end)


	-- ------------------------------------------------------------------------ #
	-- Chaos director: the physical side of an event (gravity and friction) must be\
	-- applied exactly and always removed. Runs against the real modules.
	-- ------------------------------------------------------------------------ #
	local function directorFixture()
		-- One Mock per fixture: a module's `workspace` is *that* mock's Workspace.
		local e=Mock.new(sources,schema,{fast=true})
		local EventDirector=e:import("src/server/EventDirector.luau")
		local ChaosRules=e:import("src/server/core/ChaosRules.luau")
		local World=e:import("src/server/WorldService.luau")
		local Config=e:import("src/shared/Config.luau")
		e.services.Workspace.Gravity=Config.NormalGravity
		local root=World.new().root
		local director=EventDirector.new(Config.NormalGravity)
		return e,root,director,ChaosRules,Config
	end
	local function find(root,name) return root:FindFirstChild(name,true) end
	local function surfaces(e)
		local parts={}
		for _,part in e.services.Workspace:GetDescendants() do
			if part:IsA("BasePart") and part.Name~="BrainCell" then table.insert(parts,part) end
		end
		return parts
	end

	test("director: a Chaos window sets gravity and the neutral set restores it",function()
		local e,root,director,ChaosRules,Config=directorFixture()
		director:apply(ChaosRules.modifiers("LowGravity",Config))
		eq(e.services.Workspace.Gravity,Config.Chaos.LowGravity)
		director:apply(ChaosRules.modifiers("LowGravity",Config))
		eq(e.services.Workspace.Gravity,Config.Chaos.LowGravity)
		director:apply(ChaosRules.modifiers("",Config))
		eq(e.services.Workspace.Gravity,Config.NormalGravity)
	end)
	test("director: Slippery Chaos changes friction on every surface and restores each one exactly",function()
		local e,root,director,ChaosRules,Config=directorFixture()
		local parts=surfaces(e)
		assert(#parts>0,"the world must contain surfaces")
		-- Author one surface with its own physical properties, to prove restoration is exact.
		local authored={_type="PhysicalProperties",Friction=.25,Density=1.5}
		parts[1].CustomPhysicalProperties=authored
		director:apply(ChaosRules.modifiers("SlipperyChaos",Config))
		for _,part in parts do near(part.CustomPhysicalProperties.Friction,Config.SlipperyFriction) end
		director:apply(ChaosRules.modifiers("",Config))
		assert(parts[1].CustomPhysicalProperties==authored,"the authored surface must be restored to its own properties")
		for index=2,#parts do eq(parts[index].CustomPhysicalProperties,nil) end
	end)
	test("director: reset clears gravity and friction even in the middle of an event",function()
		local e,root,director,ChaosRules,Config=directorFixture()
		local parts=surfaces(e)
		director:apply(ChaosRules.modifiers("SlipperyChaos",Config))
		director:apply(ChaosRules.modifiers("LowGravity",Config))
		director:reset()
		eq(e.services.Workspace.Gravity,Config.NormalGravity)
		for _,part in parts do eq(part.CustomPhysicalProperties,nil) end
	end)
	test("director: switching kinds never leaves the previous kind's effect behind",function()
		local e,root,director,ChaosRules,Config=directorFixture()
		local parts=surfaces(e)
		director:apply(ChaosRules.modifiers("LowGravity",Config))
		director:apply(ChaosRules.modifiers("SlipperyChaos",Config))
		eq(e.services.Workspace.Gravity,Config.NormalGravity)
		near(parts[1].CustomPhysicalProperties.Friction,Config.SlipperyFriction)
		director:apply(ChaosRules.modifiers("BouncyWorld",Config))
		eq(e.services.Workspace.Gravity,Config.NormalGravity)
		for _,part in parts do eq(part.CustomPhysicalProperties,nil) end
	end)
	test("director: a surface destroyed during an event is skipped on restore",function()
		local e,root,director,ChaosRules,Config=directorFixture()
		local parts=surfaces(e)
		director:apply(ChaosRules.modifiers("SlipperyChaos",Config))
		parts[1].Parent=nil
		director:apply(ChaosRules.modifiers("",Config))
		for index=2,#parts do eq(parts[index].CustomPhysicalProperties,nil) end
	end)
	test("director: retired map geometry stays parked and never moves during any event",function()
		local e,root,director,ChaosRules,Config=directorFixture()
		local deck=find(root,"EventRaft_A_Deck")
		local span=find(root,"EventPath_0_Span_0")
		assert(deck and span,"the baked geometry is kept in the map")
		local deckPose,spanPose=deck.CFrame,span.CFrame
		for _,kind in Config.Chaos.Kinds do
			director:apply(ChaosRules.modifiers(kind,Config))
			director:apply(ChaosRules.modifiers("",Config))
		end
		eq(deck.CanCollide,false); eq(span.CanCollide,false)
		assert((deck.CFrame.Position-deckPose.Position).Magnitude<.001,"a retired raft must not move")
		assert((span.CFrame.Position-spanPose.Position).Magnitude<.001,"a retired span must not move")
	end)

	-- ------------------------------------------------------------------------ #
	-- Persistence (spec §8): secure, schema-checked, failure-tolerant saves.
	-- The mock DataStore is in-memory and deterministic.
	-- ------------------------------------------------------------------------ #
	local Persistence
	local storeProbe=Mock.new(sources,schema,{fast=true})
	Persistence=storeProbe:import("src/server/Persistence.luau")

	test("steal: a real client tag moves a carried cell and reports both sides",function()
		local e,a,b=fixture({fast=true,studio=true},true)
		play(e)
		-- Give the victim something to lose, through the engine's own pickup path.
		collect(e,b,1)
		local before=score(b)
		assert(before>0,"the victim needs a carried cell")
		-- Put the two characters inside the configured range, then ask to steal.
		local base=a.Character.HumanoidRootPart.Position
		b.Character:PivotTo(e.CFrame.new(base+e.Vector3.new(3,0,0)))
		e:step(6)   -- clear spawn protection and let the client snapshot settle
		e:request(a,"Steal")
		eq(score(a)>0,true)
		eq(score(b)<before,true)
		local line=""
		for _,entry in e:logsMatching("[Brainrot] steal") do line=line.." | "..entry end
		assert(string.find(line,"steal ok",1,true),"the server must report a successful steal:"..line)
	end)
	test("steal: out of range is refused by the server, not the client",function()
		local e,a,b=fixture({fast=true,studio=true},true)
		play(e)
		collect(e,b,1)
		local before=score(b)
		local base=a.Character.HumanoidRootPart.Position
		b.Character:PivotTo(e.CFrame.new(base+e.Vector3.new(60,0,0)))
		e:step(6)
		e:request(a,"Steal")
		eq(score(b),before)
		eq(score(a),0)
	end)
	test("steal: the request carries no arguments, so nothing can be forged",function()
		local e,a=fixture({fast=true,studio=true},true)
		play(e)
		-- Extra arguments are rejected wholesale by the whitelist.
		e:request(a,"Steal",-1,999)
		e:step(.1)
		eq(score(a),0)
	end)
	test("persistence: a missing record becomes a valid default profile",function()
		local p=Persistence.sanitise(nil)
		eq(p.Coins,0); eq(p.Halo,"None"); eq(p.Rounds,0)
		eq(next(p.Specimens),nil)
	end)
	test("persistence: corrupt fields are repaired, not trusted",function()
		local p=Persistence.sanitise({
			Coins="lots", Halo="Invisible", Rounds=-5, Wins=99, BestScore=math.huge,
			Specimens={brain=-3, frog=2, [5]=1, hacker=1e9},
		})
		eq(p.Coins,0); eq(p.Halo,"None"); eq(p.Rounds,0)
		-- wins can never exceed rounds played
		eq(p.Wins,0)
		eq(p.BestScore,0)
		-- a non-positive or non-string key is dropped entirely, not clamped to zero
		eq(p.Specimens.brain,nil)
		eq(p.Specimens[5],nil)
		eq(p.Specimens.frog,2)
		eq(p.Specimens.hacker,100000)
	end)
	test("persistence: only the six known halos can be equipped",function()
		local p=Persistence.sanitise({Halo="Violet"}); eq(p.Halo,"Violet")
		eq(Persistence.sanitise({Halo="Rainbow"}).Halo,"None")
	end)
	test("persistence: a round is paid once, from the server's result",function()
		local p=Persistence.sanitise(nil)
		Persistence.applyRound(p,{score=42,steals=2,lost=5,pickups=9,coins=30,won=true,
			collection={brain=3,fish=1}})
		eq(p.Rounds,1); eq(p.TotalScore,42); eq(p.Steals,2); eq(p.Lost,5)
		eq(p.Picked,9); eq(p.Coins,30); eq(p.Wins,1); eq(p.BestScore,42)
		eq(p.Specimens.brain,3); eq(p.Specimens.fish,1)
		-- a worse round still counts, but cannot lower the best
		Persistence.applyRound(p,{score=10,steals=0,lost=0,pickups=1,coins=10,won=false})
		eq(p.Rounds,2); eq(p.BestScore,42); eq(p.Wins,1); eq(p.Coins,40)
	end)
	test("persistence: coins are spend-proof — a halo costs its server price",function()
		local store=Persistence.new({memoryOnly=true})
		store.profiles[-1]=Persistence.sanitise({Coins=40,Halo="None"})
		local ok,reason=store:buyHalo(-1,"Cyan",100)
		eq(ok,false); eq(reason,"poor")
		eq(store.profiles[-1].Coins,40)
		store.profiles[-1].Coins=100
		local ok2,reason2=store:buyHalo(-1,"Cyan",100)
		eq(ok2,true); eq(reason2,"ok")
		eq(store.profiles[-1].Coins,0); eq(store.profiles[-1].Halo,"Cyan")
		-- and a halo it does not sell is refused outright
		eq((store:buyHalo(-1,"Hacker",0)),false)
	end)
	test("persistence: a saved profile reloads with the same coins and specimens",function()
		local store=Persistence.new({memoryOnly=false,persistInStudio=true})
		-- Load first: since Phase 7A only a Loaded profile is writable, so the test
		-- must reach the real state machine instead of writing into the cache.
		store:load(-7)
		eq(store:state(-7),"Loaded")
		store.profiles[-7]=Persistence.sanitise({Coins=250,Specimens={toast=2},Halo="Gold"})
		store:save(-7)
		assert(store.writes==1,"the save must reach the store")
		local reopened=Persistence.new({memoryOnly=false,persistInStudio=true})
		reopened:load(-7)
		local p=reopened:profile(-7)
		eq(p.Coins,250); eq(p.Specimens.toast,2); eq(p.Halo,"Gold")
	end)
	test("persistence: an unavailable DataStore degrades to memory, never crashes",function()
		local store=Persistence.new({memoryOnly=false,persistInStudio=true,storeFail=true})
		store:load(-9)
		local p=store:profile(-9)
		assert(p~=nil,"a profile must exist even without storage")
		eq(p.Coins,0)
		store.profiles[-9].Coins=5
		store:save(-9)
		eq(store.profiles[-9].Coins,5)
		assert(store.errors>0,"the failure must be counted, not hidden")
	end)
	test("director: a character that spawns during Slippery Chaos gets the same friction, and nothing is left behind",function()
		local e,root,director,ChaosRules,Config=directorFixture()
		local ws=e.services.Workspace
		director:apply(ChaosRules.modifiers("SlipperyChaos",Config))
		local model=e.new("Model"); model.Name="LateJoiner"
		local torso=e.new("Part"); torso.Name="Torso"; torso.Parent=model
		model.Parent=ws
		near(torso.CustomPhysicalProperties.Friction,Config.SlipperyFriction)
		-- A respawn is a new model: the old one is gone, the new one must get friction too.
		model:Destroy()
		local again=e.new("Model"); again.Name="Respawn"
		local torso2=e.new("Part"); torso2.Name="Torso"; torso2.Parent=again
		again.Parent=ws
		near(torso2.CustomPhysicalProperties.Friction,Config.SlipperyFriction)
		director:apply(ChaosRules.modifiers("",Config))
		eq(torso2.CustomPhysicalProperties,nil)
		eq(director.frictionOn,false)
		eq(ws.Gravity,Config.NormalGravity)
	end)
	test("director: the friction watcher is disconnected at the window's end, so later spawns are untouched",function()
		local e,root,director,ChaosRules,Config=directorFixture()
		local ws=e.services.Workspace
		director:apply(ChaosRules.modifiers("SlipperyChaos",Config))
		director:apply(ChaosRules.modifiers("",Config))
		local late=e.new("Part"); late.Name="AfterTheEvent"; late.Parent=ws
		eq(late.CustomPhysicalProperties,nil)
		eq(director.watcher,nil)
	end)
	test("director: repeated Slippery ticks write friction once, not every tick",function()
		local e,root,director,ChaosRules,Config=directorFixture()
		director:apply(ChaosRules.modifiers("SlipperyChaos",Config))
		local writes=0
		local probe=e.new("Part"); probe.Name="Probe"; probe.Parent=e.services.Workspace
		local first=probe.CustomPhysicalProperties
		for _=1,50 do director:apply(ChaosRules.modifiers("SlipperyChaos",Config)) end
		eq(probe.CustomPhysicalProperties,first)
		eq(director.frictionValue,Config.SlipperyFriction)
		director:reset()
		eq(probe.CustomPhysicalProperties,nil)
	end)
	-- ---- dynamic audio (client controller on the mock SoundService) ----------
	local function audioFixture(trackId,cueId)
		local e=Mock.new(sources,schema,{fast=true})
		local Config=e:import("src/shared/Config.luau")
		local config=table.clone(Config); config.Audio=table.clone(Config.Audio)
		config.Audio.Tracks=table.clone(Config.Audio.Tracks); config.Audio.Cues=table.clone(Config.Audio.Cues)
		if trackId then config.Audio.Tracks.Chaos=trackId end
		if cueId then config.Audio.Cues.Steal=cueId end
		local Audio=e:import("src/client/Audio.luau")
		return e,config,Audio,Audio.new(config)
	end
	test("audio: the Chaos track crossfades in during an event and back out afterwards",function()
		local e,config,Audio,a=audioFixture("rbxassetid://111")
		local chaos=a.folder:FindFirstChild("Music_Chaos")
		assert(chaos,"a configured track gets a Sound")
		eq(chaos.SoundId,"rbxassetid://111")
		eq(a.folder:FindFirstChild("Music_Arena"),nil) -- unconfigured tracks create no Sound
		a:setState({phase="Playing",eventActive=false,eventKind=""}); a:tick(.1,true)
		a:setState({phase="Playing",eventActive=true,eventKind="BrainCellRush"})
		for _=1,10 do a:tick(.1,true) end
		assert(chaos.Volume>0,"the Chaos track is audible during the event")
		assert(chaos.Volume<=config.Audio.MusicVolume+1e-9,"never louder than configured")
		for _=1,100 do a:tick(.1,true) end
		near(chaos.Volume,config.Audio.MusicVolume)
		a:setState({phase="Playing",eventActive=false,eventKind=""})
		for _=1,30 do a:tick(.1,true) end
		near(chaos.Volume,0)
	end)
	test("audio: the Sound setting mutes music and cues, and destroy removes everything it made",function()
		local e,config,Audio,a=audioFixture("rbxassetid://111","rbxassetid://222")
		a:setState({phase="Playing",eventActive=true,eventKind="LowGravity"})
		for _=1,60 do a:tick(.1,false) end
		near(a.folder:FindFirstChild("Music_Chaos").Volume,0)
		eq(a:cue("Steal"),false)
		a:tick(.1,true)
		eq(a:cue("Steal"),true)
		a:destroy()
		eq(a.folder.Parent,nil)
	end)
	test("audio: cues play only when configured, and an unknown cue name is an error",function()
		local e,config,Audio,a=audioFixture(nil,nil)
		eq(a:cue("Ability"),false)              -- the reserved ability slot is empty by default
		assert(not pcall(function() a:cue("Ability.Dash") end),"an unknown cue must be an error")
		a:destroy()
	end)
	test("audio: joining mid-event plays no stinger; the next real edge does",function()
		local e,config,Audio,a=audioFixture("rbxassetid://111")
		config.Audio.Cues.ChaosStart="rbxassetid://333"; config.Audio.Cues.ChaosEnd="rbxassetid://334"
		a:setState({phase="Playing",eventActive=true,eventKind="SlipperyChaos"}) -- first snapshot: no stinger
		eq(#a.folder:GetChildren(),1)                                           -- only the Chaos music Sound
		a:setState({phase="Playing",eventActive=false,eventKind=""})            -- a real edge: ChaosEnd plays
		eq(#a.folder:GetChildren(),2)
		a:destroy()
	end)
	-- ---- characters and abilities (live server, mock boundary) ----------------
	local function remotesOf(e) return e.services.ReplicatedStorage.BrainrotRemotes end
	local function viewsFor(e,p)
		local views={}
		for _,log in e.logs do
			if log.name=="CharacterState" and log.player==p.UserId then table.insert(views,log.args[1]) end
		end
		return views
	end
	local function lastView(e,p)
		local views=viewsFor(e,p)
		return views[#views]
	end
	local function switchTo(e,p,slot)
		e:step(.3); remotesOf(e).Character.OnServerEvent:Fire(p,slot)
		return lastView(e,p)
	end
	local function useAbility(e,p)
		e:step(.3); remotesOf(e).Ability.OnServerEvent:Fire(p)
		return lastView(e,p)
	end
	local function serverConfig(e) return e:import("src/shared/Config.luau") end
	local function setPosition(p,target) p.Character:PivotTo(target) end
	-- The movement guard treats a jump as a teleport and pulls it back, exactly as it would
	-- in a live server. So the helper walks a player to the target at 15 studs a second,
	-- under the 22 stud walk speed, one simulated second per step.
	local function walkTo(e,p,x,z)
		for _=1,20 do
			local root=p.Character.HumanoidRootPart
			local cur=root.Position
			local dx,dz=x-cur.X,z-cur.Z
			local d=math.sqrt(dx*dx+dz*dz)
			if d<.05 then break end
			local s=math.min(d,15)
			local to=e.CFrame.new(cur.X+dx/d*s,cur.Y,cur.Z+dz/d*s)
			root.CFrame=to
			p.Character.Head.CFrame=e.CFrame.new(to.Position.X,cur.Y+3,to.Position.Z)
			e:step(1)
		end
	end
	local function nearCaster(e,a,b,offset)
		local at=a.Character.HumanoidRootPart.Position
		walkTo(e,b,at.X+offset,at.Z)
	end
	local function speedOf(p) return p.Character.Humanoid.WalkSpeed end
	local function groundedVelocity(p) return p.Character.HumanoidRootPart.AssemblyLinearVelocity end
	local function horizontal(v) return math.sqrt(v.X*v.X+v.Z*v.Z) end

	test("abilities: the Ability remote rejects any argument, and Character rejects bad slots with a reason",function()
		local e,a,b=fixture({fast=true,studio=true,roll=.1},true); play(e)
		local before=#viewsFor(e,a)
		remotesOf(e).Ability.OnServerEvent:Fire(a,"Mind Trick"); e:step(.3)
		eq(#viewsFor(e,a),before)                                      -- silently refused, nothing started
		remotesOf(e).Character.OnServerEvent:Fire(a,2,3); e:step(.3)
		eq(#viewsFor(e,a),before)                                      -- two arguments: refused
		local bad=switchTo(e,a,9)
		eq(bad.notice,"NO SUCH CHARACTER")
		eq(switchTo(e,a,"2").notice,"NO SUCH CHARACTER")
		eq(switchTo(e,a,1.5).notice,"NO SUCH CHARACTER")
		eq(lastView(e,a).normalLeft,3)                                 -- no quota was spent
	end)

	test("switching: three normal switches per round; the bonus switch is refused outside Chaos and allowed during it",function()
		local e,a=fixture({fast=true,studio=true,roll=.1},true); play(e)
		eq(lastView(e,a).active,"brain")
		eq(switchTo(e,a,2).active,"frog"); eq(switchTo(e,a,3).active,"fish"); eq(switchTo(e,a,4).active,"goose")
		local v=lastView(e,a); eq(v.normalLeft,0); eq(v.active,"goose")
		eq(switchTo(e,a,5).notice,"BONUS SWITCH: CHAOS EVENT ONLY")    -- no bonus before Chaos
		e:step(8.01)                                                  -- the Chaos Event opens at 8 s
		eq(lastView(e,a).bonusLeft,1)
		eq(switchTo(e,a,5).active,"toast")                             -- the one bonus switch
		eq(switchTo(e,a,6).notice,"NO SWITCHES LEFT THIS ROUND")      -- four in total, never a fifth
	end)

	test("cooldowns: independent per character, persist across switches, and are refused while cooling",function()
		local e,a,b=fixture({fast=true,studio=true,roll=.1},true); play(e)
		local Config=serverConfig(e)
		switchTo(e,a,2)                                                -- frog: Belly Bounce
		local first=useAbility(e,a)
		assert(first.notice:find("BELLY BOUNCE"),"the frog ability ran: "..first.notice)
		local readyFrog=first.readyAt.frog
		near(readyFrog-e.now,Config.Characters.Roster.frog.Cooldown,.3)
		switchTo(e,a,3)                                                -- fish is ready at once: its cooldown is its own
		local fishView=useAbility(e,a)
		assert(fishView.notice:find("BUBBLE DASH"),"fish ability is independent: "..fishView.notice)
		switchTo(e,a,2)                                                -- back to frog: still cooling
		local refused=useAbility(e,a)
		eq(refused.notice,"ABILITY RECHARGING")
		eq(math.abs(lastView(e,a).readyAt.frog-readyFrog)<.001,true)  -- switching changed no cooldown
	end)

	test("knockback: Belly Bounce pushes opponents in range, never the caster, and spares those out of range",function()
		local e,a,b=fixture({fast=true,studio=true,roll=.1},true); play(e)
		local Config=serverConfig(e)
		local c=e:addPlayer(-3,"Far Brain"); e:step(.3)
		switchTo(e,a,2)
		nearCaster(e,a,b,5)                                            -- inside Radius 10
		walkTo(e,c,a.Character.HumanoidRootPart.Position.X-20,a.Character.HumanoidRootPart.Position.Z)  -- 20 studs away: out of range
		local aBefore=groundedVelocity(a)
		local view=useAbility(e,a)
		assert(view.notice:find("1 HIT"),"one opponent hit: "..view.notice)
		local push=groundedVelocity(b)
		near(horizontal(push),Config.Characters.Roster.frog.Push,.001)
		near(push.Y,Config.Characters.Roster.frog.Lift,.001)
		eq(groundedVelocity(a).X,aBefore.X)                            -- the caster was not moved
		eq(groundedVelocity(a).Z,aBefore.Z)
		eq(horizontal(groundedVelocity(c)),0)                          -- out of range: untouched
	end)

	test("bubble dash: the caster moves along its facing for the duration, then stops",function()
		local e,a=fixture({fast=true,studio=true,roll=.1},true); play(e)
		local Config=serverConfig(e)
		switchTo(e,a,3)
		useAbility(e,a); e:step(.1)
		near(horizontal(groundedVelocity(a)),Config.Characters.Roster.fish.Speed,.001)
		e:step(Config.Characters.Roster.fish.Duration+.3)
		a.Character.HumanoidRootPart.AssemblyLinearVelocity=e.Vector3.new(0,0,0)
		e:step(.3)
		eq(horizontal(groundedVelocity(a)),0)                          -- not re-applied after the dash
	end)

	test("slows: Honk Wave slows opponents in range for its duration, the caster is untouched, and the speed comes back",function()
		local e,a,b=fixture({fast=true,studio=true,roll=.1},true); play(e)
		local Config=serverConfig(e)
		switchTo(e,a,4)
		nearCaster(e,a,b,6)
		useAbility(e,a); e:step(.2)
		near(speedOf(b),Config.WalkSpeed*Config.Characters.Roster.goose.SlowFactor,.001)
		eq(speedOf(a),Config.WalkSpeed)
		e:step(Config.Characters.Roster.goose.Duration+.2)
		near(speedOf(b),Config.WalkSpeed,.001)
	end)

	test("slows: Sock Snare slows a rival to its factor, and the caster keeps full speed (merge rules are in core)",function()
		local e,a,b=fixture({fast=true,studio=true,roll=.1},true); play(e)
		local Config=serverConfig(e)
		switchTo(e,a,6)
		nearCaster(e,a,b,4)
		useAbility(e,a); e:step(.2)
		near(speedOf(b),Config.WalkSpeed*Config.Characters.Roster.sock.SlowFactor,.001)
		eq(speedOf(a),Config.WalkSpeed)
	end)

	test("launch: Toast Launch lifts opponents straight up with no sideways part",function()
		local e,a,b=fixture({fast=true,studio=true,roll=.1},true); play(e)
		local Config=serverConfig(e)
		switchTo(e,a,5)
		nearCaster(e,a,b,4)
		useAbility(e,a)
		local v=groundedVelocity(b)
		near(v.Y,Config.Characters.Roster.toast.Lift,.001)
		near(horizontal(v),0,.001)
	end)

	test("decoy: Mind Trick shows a non-colliding copy of the caster that is removed when the round ends",function()
		local e,a=fixture({fast=true,studio=true,roll=.1},true); play(e)
		local view=useAbility(e,a)
		assert(view.notice:find("DECOY LIVE"),"decoy started: "..view.notice)
		local decoy=e.services.Workspace:FindFirstChild("MindTrick_"..tostring(a.UserId))
		assert(decoy~=nil,"the decoy model exists while the round runs")
		local parts=0
		for _,part in decoy:GetDescendants() do
			if part:IsA("BasePart") then
				parts+=1
				eq(part.CanCollide,false); eq(part.Anchored,true)
			end
		end
		assert(parts>0,"the decoy has visible parts")
		e:step(60)                                                     -- past the end of the round
		eq(e.services.Workspace:FindFirstChild("MindTrick_"..tostring(a.UserId)),nil)
	end)

	test("abilities never change Brain Cells: every character's ability leaves every score exactly as it was",function()
		local rolls={.1,.4,.6,.9}
		for index,slot in {2,3,4,5,6,1} do
			local e,a,b=fixture({fast=true,studio=true,roll=rolls[(index-1)%4+1]},true); play(e)
			nearCaster(e,a,b,4)
			if slot~=1 then switchTo(e,a,slot) end
			local aBefore,bBefore=score(a),score(b)
			useAbility(e,a)
			eq(score(a),aBefore); eq(score(b),bBefore)
		end
	end)

	test("names: the name tag shows the active character and follows a switch",function()
		local e,a=fixture({fast=true,studio=true,roll=.1},true); play(e)
		local tag=a.Character.Head:FindFirstChild("CharacterTag")
		assert(tag~=nil,"a tag is attached to the head")
		eq(tag:FindFirstChild("Label").Text,"BRAINY")
		switchTo(e,a,2); e:step(.1)
		eq(a.Character.Head:FindFirstChild("CharacterTag"):FindFirstChild("Label").Text,"BLORBO")
	end)

	test("respawn: a respawn clears slows and dashes, but keeps the cooldown",function()
		local e,a,b=fixture({fast=true,studio=true,roll=.1},true); play(e)
		local Config=serverConfig(e)
		switchTo(e,a,4); nearCaster(e,a,b,6)
		useAbility(e,a); e:step(.2)
		near(speedOf(b),Config.WalkSpeed*Config.Characters.Roster.goose.SlowFactor,.001)
		e:spawn(b); e:step(.5)
		near(speedOf(b),Config.WalkSpeed,.001)                         -- the new character is not slowed
		local ready=lastView(e,a).readyAt.goose
		assert(ready>e.now,"the caster's cooldown is still running")
	end)

	test("hud: the ability button, Q, the number keys and the strip all send the right verbs",function()
		local e,a=fixture({fast=true,studio=true,roll=.1},true); play(e)
		e:find("AbilityButton").Activated:Fire()
		e:step(.3)
		assert(lastView(e,a).notice:find("DECOY LIVE"),"button fires the ability: "..lastView(e,a).notice)
		e:step(.3); e:press("Two"); e:step(.1)
		eq(lastView(e,a).active,"frog")
		e:step(.3); e:find("Slot3").Activated:Fire(); e:step(.1)
		eq(lastView(e,a).active,"fish")
		e:step(.3); e:press("Q")
		assert(lastView(e,a).notice:find("BUBBLE DASH"),"Q fires the active ability: "..lastView(e,a).notice)
	end)

	test("hud: the strip names the active character and the switches left",function()
		local e,a=fixture({fast=true,studio=true,roll=.1},true); play(e)
		e:step(.1)
		assert(e:find("Readout").Text:find("BRAINY"),"readout: "..e:find("Readout").Text)
		switchTo(e,a,2); e:step(.1)
		assert(e:find("Readout").Text:find("BLORBO"),"readout follows the switch")
		assert(e:find("Readout").Text:find("2 SWITCHES LEFT"),"readout counts switches: "..e:find("Readout").Text)
	end)

	test("startup: a missing server remote shows a visible startup error instead of a silent hang",function()
		local e,a=fixture({fast=true,studio=true,roll=.1},false)
		e.services.ReplicatedStorage:FindFirstChild("BrainrotRemotes"):Destroy()
		e:startClient(a)
		local gui=a.PlayerGui:FindFirstChild("BrainrotStartupError")
		assert(gui~=nil,"the player sees a startup error panel")
		assert(gui:FindFirstChild("TextLabel",true).Text:find("BrainrotRemotes",1,true),"the panel names the missing piece")
		eq(a.PlayerGui:FindFirstChild("BrainrotHUD"),nil)
	end)

	test("startup: a healthy server builds the HUD and no startup error",function()
		local e,a=fixture({fast=true,studio=true,roll=.1},true)
		assert(a.PlayerGui:FindFirstChild("BrainrotHUD")~=nil,"HUD is built")
		eq(a.PlayerGui:FindFirstChild("BrainrotStartupError"),nil)
	end)

	-- ------------------------------------------------------------------------ #
	-- PHASE 7A: persistence safety. A profile is writable only after a read that
	-- actually established it. Each test below names the failure it locks down.
	-- ------------------------------------------------------------------------ #
	local function seededVeteran()
		return { Version=1, Coins=5000, Halo="Cyan", Specimens={toast=9}, Rounds=120,
			Wins=40, BestScore=310, TotalScore=9000, Steals=30, Lost=12, Picked=800 }
	end
	-- A live-server Persistence over the mock DataStore, with its store pre-seeded.
	local function persistFixture(options, seed)
		local opts = options or {}
		opts.studio = false
		local e = Mock.new(sources, schema, opts)
		local Persistence = e:import("src/server/Persistence.luau")
		local store = Persistence.new({ memoryOnly = false, persistInStudio = true })
		if seed then
			for _, underlying in e.stores do underlying[Persistence.key(-42)] = seed end
		end
		return e, Persistence, store
	end
	local function stored(e, Persistence)
		local found = nil
		for _, underlying in e.stores do found = underlying[Persistence.key(-42)] end
		return found
	end

	test("7A-A: existing profile + successful load + save round-trips",function()
		local e,Persistence,store=persistFixture({}, seededVeteran())
		local loaded = store:load(-42)
		eq(store:state(-42),"Loaded")
		eq(loaded.Coins,5000)
		eq(store:isWritable(-42),true)
		loaded.Coins = 5100
		local ok,reason = store:save(-42)
		eq(ok,true)
		-- "queued" (dispatched) or "joined"/"unchanged" (nothing new to write) are
		-- all acceptance; "ok" is no longer returned because the write is async.
		assert(reason=="queued" or reason=="joined" or reason=="unchanged",
			"unexpected save reason: "..tostring(reason))
		eq(stored(e,Persistence).Coins,5100)
	end)

	test("7A-B: a confirmed nil read is a new player and may be written",function()
		local e,Persistence,store=persistFixture({})
		local fresh = store:load(-42)
		eq(store:state(-42),"Loaded")
		eq(fresh.Coins,0)
		eq(store:isWritable(-42),true)
		fresh.Coins = 10
		eq((store:save(-42)),true)
		eq(stored(e,Persistence).Coins,10)
	end)

	test("7A-C: a failed read refuses the save and never overwrites the record",function()
		local e,Persistence,store=persistFixture({readFail=true}, seededVeteran())
		local shell = store:load(-42)
		eq(store:state(-42),"Failed")
		eq(store:isWritable(-42),false)
		-- Even a caller that mutates the shell cannot persist it.
		shell.Coins = 999999
		local ok,reason = store:save(-42)
		eq(ok,false); eq(reason,"not-ready")
		eq(store.writes,0,"no write may reach the store")
		eq(stored(e,Persistence).Coins,5000,"the real record is untouched")
		eq(stored(e,Persistence).Rounds,120)
		assert(store.refusedSaves>0,"the refusal must be counted")
	end)

	test("7A-D: a save before the load completes is refused",function()
		local e,Persistence,store=persistFixture({deferAsync=true}, seededVeteran())
		local shell = store:load(-42)
		eq(store:state(-42),"Loading")
		eq(store:isWritable(-42),false)
		shell.Coins = 777
		eq((store:save(-42)),false,"a Loading profile must not be written")
		eq(stored(e,Persistence).Coins,5000)
		-- The read lands: the profile becomes writable and the save now succeeds.
		e:flushAsync()
		eq(store:state(-42),"Loaded")
		eq(store:profile(-42).Coins,5000)
		eq((store:save(-42)),true)
		eq(stored(e,Persistence).Coins,5000)
	end)

	test("7A-E: a player who leaves while the load is pending is never written",function()
		local e,Persistence,store=persistFixture({deferAsync=true}, seededVeteran())
		store:load(-42)
		eq(store:state(-42),"Loading")
		-- PlayerRemoving path: release the session, then the response arrives.
		store:release(-42)
		eq(store:profile(-42),nil)
		eq(e:flushAsync()>0,true,"the read was really in flight")
		eq(store:profile(-42),nil,"a late load must not resurrect the session")
		eq(store:state(-42),"Leaving")
		-- A save for the departed session is refused too, so the resurrected
		-- profile cannot be written even if a caller still holds a reference.
		eq((store:save(-42)),false,"a departed session must not be written")
		eq(stored(e,Persistence).Coins,5000,"nothing was written for a departed player")
		-- A rejoin starts a clean generation and works normally.
		store:load(-42)
		eq(store:state(-42),"Loading","a rejoin starts a fresh generation")
		e:flushAsync()
		eq(store:state(-42),"Loaded")
		eq(store:profile(-42).Coins,5000)
	end)

	test("7A-F: a failed load can be retried successfully",function()
		local e,Persistence,store=persistFixture({readFail=true}, seededVeteran())
		store:load(-42)
		eq(store:state(-42),"Failed")
		eq((store:save(-42)),false)
		-- The outage clears and the caller asks for one explicit retry.
		e.options.readFail = false
		store:load(-42,function() end,{retry=true})
		eq(store:state(-42),"Loaded")
		eq(store:profile(-42).Coins,5000)
		eq(store:isWritable(-42),true)
		eq((store:save(-42)),true)
		eq(stored(e,Persistence).Coins,5000)
	end)

	test("7A-G: a failed write leaves the in-memory profile intact and a retry works",function()
		local e,Persistence,store=persistFixture({}, seededVeteran())
		store:load(-42)
		local profile = store:profile(-42)
		profile.Coins = 5300
		-- The write fails every retry.
		e.options.writeFail = true
		eq((store:save(-42)),true,"the request was accepted")
		eq(store:profile(-42).Coins,5300,"the in-memory profile is not corrupted")
		eq(stored(e,Persistence).Coins,5000,"the store still holds the old value")
		assert(store.errors>0,"the failure is counted")
		-- The outage clears; the next save point writes the correct value.
		e.options.writeFail = false
		eq((store:save(-42)),true)
		eq(stored(e,Persistence).Coins,5300)
	end)

	test("7A-H: the acceptance namespace is isolated and cannot be production",function()
		local e=Mock.new(sources,schema,{studio=false})
		local Persistence=e:import("src/server/Persistence.luau")
		-- Production default is unchanged and needs no configuration.
		local prod=Persistence.new({})
		eq(prod.storeName,"BrainrotArenaProfiles")
		eq(prod.acceptance,false)
		-- An explicit acceptance namespace is accepted and is a different store.
		local acc=Persistence.new({acceptance=true,storeName="BrainrotArenaAcceptance_p7a"})
		eq(acc.storeName,"BrainrotArenaAcceptance_p7a")
		assert(acc.storeName~=prod.storeName,"acceptance must not share production keys")
		-- Anything that could reach live progression is refused outright.
		eq(pcall(Persistence.new,{acceptance=true,storeName="BrainrotArenaProfiles"}),false)
		eq(pcall(Persistence.new,{storeName="BrainrotArenaProfiles",acceptance=true}),false)
		eq(pcall(Persistence.new,{storeName="BrainrotArena_typo"}),false)
		eq(pcall(Persistence.new,{storeName="BrainrotArenaAcceptance_"}),false)
		eq(pcall(Persistence.new,{acceptance=true}),false)
		eq(pcall(Persistence.new,{storeName=42}),false)
		-- A plain custom name is not a bypass either.
		eq(pcall(Persistence.new,{storeName="SomeOtherStore"}),false)
	end)

	test("7A-end-to-end: a join during an outage cannot wipe a veteran profile",function()
		local e=Mock.new(sources,schema,{fast=false,studio=false,readFail=true})
		local Persistence=e:import("src/server/Persistence.luau")
		local key=Persistence.key(-42)
		local seed=seededVeteran()
		local a=e:addPlayer(-42,"Veteran")
		e:startServer(); e:step(.1)
		for _,underlying in e.stores do underlying[key]=seed end
		-- Force the in-flight read to fail: recreate the join after seeding.
		e:removePlayer(a)
		local b=e:addPlayer(-42,"Veteran"); e:step(.1); e:step(1)
		e:removePlayer(b); e:step(1)
		local after=nil
		for _,underlying in e.stores do after=underlying[key] end
		eq(after.Coins,5000,"the veteran's coins survived a failed read")
		eq(after.Rounds,120,"the veteran's stats survived a failed read")
		eq(after.Specimens.toast,9,"the veteran's specimen log survived a failed read")
	end)

	-- ------------------------------------------------------------------------ #
	-- REGRESSION: durability of the profile that carries the coins.
	--
	-- These run with `studio=false` — the *published server* context. The mock
	-- defaults to `studio=true`, which is how the survival of this bug went
	-- unnoticed: Persistence correctly stays memory-only in Studio, so a Studio
	-- fixture can never prove that a live server writes anything.
	-- ------------------------------------------------------------------------ #
	test("regression: the production server opens a DataStore and writes a profile on a payout",function()
		local e=Mock.new(sources,schema,{fast=false,studio=false,roll=.1})
		local a=e:addPlayer(-1,"Mint Brain")
		e:startServer()
		e:step(.1); e:step(12.1); e:step(.1)
		eq(e:lastState().phase,"Playing")
		-- Finish the round with a score so the payout is non-trivial.
		a.leaderstats["Brain Cells"].Value=0 -- leaderstats are refreshed from the server
		local state=e:lastState()
		e:step(state.phaseEndsAt-e.now+.05)
		eq(e:lastState().phase,"Results")
		local stores,store=0,nil
		for _,value in e.stores do stores+=1; store=value end
		eq(stores,1)                                  -- one profile store was opened at all
		assert(store~=nil,"DataStoreService:GetDataStore was never called")
		local key=next(store)
		assert(key~=nil,"nothing was written to the profile store")
		local profile=store[key]
		eq(profile.Rounds,1)                          -- the round was recorded
		assert(profile.Coins>0,"the payout reached the stored profile")
		e:removePlayer(a)
	end)

	test("regression: a live server persists coins and the specimen log across two rounds",function()
		local e=Mock.new(sources,schema,{fast=false,studio=false,roll=.1})
		local Persistence=e:import("src/server/Persistence.luau")
		local a=e:addPlayer(-1,"Mint Brain")
		local b=e:addPlayer(-2,"Pink Brain")
		e:startServer()
		e:step(.1)                                  -- the first step publishes the phase
		local function toPlaying()
			local guard=0
			while e:lastState().phase~="Playing" and guard<4 do
				e:step((e:lastState().phaseEndsAt or 0)-e.now+.05); guard+=1
			end
		end
		local function toResults()
			e:step(e:lastState().phaseEndsAt-e.now+.05)
			eq(e:lastState().phase,"Results")
		end
		local function myRow(id)
			for _,row in e:lastState().rows do if row.id==id then return row end end
		end
		toPlaying()
		collect(e,a,1); collect(e,a,2); collect(e,b,3)
		local firstRoundScore=myRow(a.UserId).score
		assert(firstRoundScore>0,"the round needs a score")
		toResults()
		local coinsAfterRound1=a.leaderstats.Coins.Value
		eq(coinsAfterRound1, 10+firstRoundScore*2+30)  -- paid, and visible in the live wallet
		toPlaying(); eq(e:lastState().roundId,2)
		collect(e,a,4); collect(e,a,5)
		toResults()
		local coinsAfterRound2=a.leaderstats.Coins.Value
		assert(coinsAfterRound2>coinsAfterRound1,"round 2 pays again")
		-- The wallet is monotonic: a payout can never re-charge an old round.
		local stores,store=0,nil
		for _,value in e.stores do stores+=1; store=value end
		eq(stores,1)
		local profile=store[Persistence.key(a.UserId)]
		assert(profile~=nil,"the stored profile exists")
		eq(profile.Rounds,2)
		eq(profile.Coins,coinsAfterRound2)
		-- Specimens are the SUM of both rounds, and were never double counted:
		-- two common catches in round 1 and two in round 2 is four, not six.
		local specimens=0
		for _,count in profile.Specimens do specimens+=count end
		eq(specimens,4)
		e:removePlayer(a); e:removePlayer(b)
	end)

	test("regression: a refused steal does not start the cooldown, and a valid steal still does",function()
		local e,a,b=fixture({fast=true,studio=true,roll=.1},true)
		local Config=e:import("src/shared/Config.luau")
		play(e); e:step(6)                       -- clear spawn protection
		local function myRow(id)
			for _,row in e:lastState().rows do if row.id==id then return row end end
		end
		-- Nobody in range: the server refuses and the cooldown stays at zero, so the
		-- HUD (which counts down from stealReadyAt) does not lie to the player.
		b.Character:PivotTo(e.CFrame.new(a.Character.HumanoidRootPart.Position+e.Vector3.new(60,0,0)))
		e:step(.5)
		e:request(a,"Steal"); e:step(.1)
		eq(myRow(a.UserId).stealReadyAt,0)
		eq(myRow(a.UserId).score,0)
		-- Now in range with something to take: the steal succeeds and the cooldown
		-- reported to the client matches the configured one.
		collect(e,b,1)
		eq(myRow(b.UserId).score>0,true)
		b.Character:PivotTo(e.CFrame.new(a.Character.HumanoidRootPart.Position+e.Vector3.new(3,0,0)))
		e:step(1)
		local now=e.now
		e:request(a,"Steal"); e:step(.1)
		assert(myRow(a.UserId).score>0,"the cell changed hands")
		near(myRow(a.UserId).stealReadyAt, now + Config.Steal.Cooldown)
	end)

	-- ------------------------------------------------------------------------ #
	-- PHASE 7B: the ServerStorage -> namespace plumbing, end to end.
	--
	-- `7A-H` proves `resolveStoreName` on its own. These run the REAL
	-- `Main.server` and assert which DataStore namespace it actually opened, so
	-- the documented acceptance setup is verified as a path, not just as a rule.
	-- ------------------------------------------------------------------------ #
	test("7B-NS-1: the published server with no config opens production only",function()
		local e=Mock.new(sources,schema,{studio=false})
		e:startServer(); e:step(.1)
		local names={}
		for name in e.stores do table.insert(names,name) end
		eq(#names,1,"exactly one namespace may be opened")
		eq(names[1],"BrainrotArenaProfiles")
	end)

	test("7B-NS-2: an AcceptanceRunId opens only the acceptance namespace",function()
		local e=Mock.new(sources,schema,{studio=false})
		local config=e.new("Configuration"); config.Name="BrainrotPersistenceConfig"
		local runId=e.new("StringValue"); runId.Name="AcceptanceRunId"
		runId.Value="p7b-test"; runId.Parent=config; config.Parent=e.services.ServerStorage
		e:startServer(); e:step(.1)
		local names={}
		for name in e.stores do table.insert(names,name) end
		eq(#names,1,"acceptance must open exactly one namespace")
		eq(names[1],"BrainrotArenaAcceptance_p7b-test")
		assert(names[1]~="BrainrotArenaProfiles","production keys must never be opened")
	end)

	test("7B-NS-3: an empty or wrong-typed run id falls back to production, never a bare prefix",function()
		-- An empty string is not an acceptance run: it must be ignored entirely,
		-- not turned into "BrainrotArenaAcceptance_", which would throw.
		for _,value in {""} do
			local e=Mock.new(sources,schema,{studio=false})
			local config=e.new("Configuration"); config.Name="BrainrotPersistenceConfig"
			local runId=e.new("StringValue"); runId.Name="AcceptanceRunId"
			runId.Value=value; runId.Parent=config; config.Parent=e.services.ServerStorage
			e:startServer(); e:step(.1)
			local names={}
			for name in e.stores do table.insert(names,name) end
			eq(names[1],"BrainrotArenaProfiles")
		end
		-- A non-StringValue child (e.g. a NumberValue pasted by mistake) is ignored
		-- too, so a malformed config cannot select anything at all.
		local e=Mock.new(sources,schema,{studio=false})
		local config=e.new("Configuration"); config.Name="BrainrotPersistenceConfig"
		local wrong=e.new("NumberValue"); wrong.Name="AcceptanceRunId"
		wrong.Value=7; wrong.Parent=config; config.Parent=e.services.ServerStorage
		e:startServer(); e:step(.1)
		local names={}
		for name in e.stores do table.insert(names,name) end
		eq(names[1],"BrainrotArenaProfiles")
	end)

	test("7B-NS-4: Studio stays memory-only even with an acceptance namespace",function()
		-- This is the constraint the manual checklist is built around: Studio
		-- playtest cannot open ANY DataStore, so durability must be accepted on a
		-- published private server. If this ever changes, the checklist changes.
		local e=Mock.new(sources,schema,{studio=true})
		local config=e.new("Configuration"); config.Name="BrainrotPersistenceConfig"
		local runId=e.new("StringValue"); runId.Name="AcceptanceRunId"
		runId.Value="p7b-test"; runId.Parent=config; config.Parent=e.services.ServerStorage
		e:startServer(); e:step(.1)
		eq(#(function() local n={} for name in e.stores do table.insert(n,name) end return n end)(),0,
			"Studio must open no DataStore at all")
		local Persistence=e:import("src/server/Persistence.luau")
		local stats=Persistence.new({acceptance=true,storeName="BrainrotArenaAcceptance_p7b-test"}).memoryOnly
		eq(Persistence.new({acceptance=true,storeName="BrainrotArenaAcceptance_p7b-test",persistInStudio=true}).memoryOnly,false)
		eq(stats,true,"Studio is memory-only without an explicit opt-in")
	end)

	-- ------------------------------------------------------------------------ #
	-- PHASE 7B: a profile survives a server restart, in the acceptance namespace.
	-- Two independent server instances over one DataStore double: what the first
	-- writes after a round, the second reads on join. This is the automated half of
	-- the "persistence across server restart" acceptance item.
	-- ------------------------------------------------------------------------ #
	test("7B-RESTART: a round payout written in one server is read by the next",function()
		local e=Mock.new(sources,schema,{fast=true,studio=false})
		local config=e.new("Configuration"); config.Name="BrainrotPersistenceConfig"
		local runId=e.new("StringValue"); runId.Name="AcceptanceRunId"
		runId.Value="p7b-restart"; runId.Parent=config; config.Parent=e.services.ServerStorage
		local a=e:addPlayer(-55,"Restarter")
		e:startServer(); e:step(.1)
		-- The key comes from the real UserId, so derive it exactly as the server does.
		local Persistence=e:import("src/server/Persistence.luau")
		local key=Persistence.key(-55)
		local underlying=e.stores["BrainrotArenaAcceptance_p7b-restart"]
		assert(underlying,"the acceptance namespace must be the one opened")
		-- A live server runs PRODUCTION timing (`fast` only applies in Studio):
		-- 12 s intermission, 180 s round. Play one full round so a payout is
		-- actually written, then let the Results edge save.
		e:step(12.2); eq(e:lastState().phase,"Playing")
		collect(e,a,2)
		e:step(190)
		local saved=underlying[key]
		assert(saved,"the round payout must have been persisted")
		assert(saved.Coins>0,"coins must be recorded")
		assert(saved.Rounds==1,"one round recorded")
		local coinsAfter,roundsAfter=saved.Coins,saved.Rounds
		e:removePlayer(a); e:step(1)
		-- A fresh server over the same namespace: the returning player loads it.
		local e2=Mock.new(sources,schema,{fast=true,studio=false})
		local config2=e2.new("Configuration"); config2.Name="BrainrotPersistenceConfig"
		local runId2=e2.new("StringValue"); runId2.Name="AcceptanceRunId"
		runId2.Value="p7b-restart"; runId2.Parent=config2; config2.Parent=e2.services.ServerStorage
		local b=e2:addPlayer(-55,"Restarter")
		e2:startServer(); e2:step(.1)
		local profile=Persistence.new({memoryOnly=false,persistInStudio=true,
			acceptance=true,storeName="BrainrotArenaAcceptance_p7b-restart"})
		profile:load(-55)
		local loaded=profile:profile(-55)
		eq(loaded.Coins,coinsAfter)
		eq(loaded.Rounds,roundsAfter)
		eq(Persistence.key(-55),key)
	end)

	-- ------------------------------------------------------------------------ #
	-- PHASE 7C: graceful shutdown.
	--
	-- These run the REAL Main.server and fire the REAL `game:BindToClose`
	-- callback through the mock's `env:shutdown()`. They prove the behaviour of
	-- OUR code against a contract double. They do NOT prove the engine's
	-- shutdown: the mock runs bindings in order and returns, while Roblox runs
	-- them concurrently and kills the instance at 30 s regardless. Engine
	-- shutdown remains a manual acceptance item.
	-- ------------------------------------------------------------------------ #
	local function shutdownFixture(options)
		local opts = options or {}
		opts.fast = true
		opts.studio = false
		local e = Mock.new(sources, schema, opts)
		local cfg = e.new("Configuration"); cfg.Name = "BrainrotPersistenceConfig"
		local rid = e.new("StringValue"); rid.Name = "AcceptanceRunId"
		rid.Value = opts.runId or "p7c-shutdown"; rid.Parent = cfg; cfg.Parent = e.services.ServerStorage
		return e, "BrainrotArenaAcceptance_" .. (opts.runId or "p7c-shutdown")
	end
	-- Seed a durable profile and let the server read it, so the session is Loaded.
	-- A server with player -42 online. `seed` is placed in the store BEFORE the
	-- server starts, because the join reads immediately: seeding afterwards would
	-- be overwritten by the first (default) record the join wrote.
	local function joinedServer(options, seed)
		local e, name = shutdownFixture(options)
		local a = e:addPlayer(-42, "Veteran")
		if seed then
			-- The server has not opened the store yet, so create the table it
			-- will bind to and pre-place the record.
			e.stores[name] = e.stores[name] or {}
			e.stores[name]["p_-42"] = seed
		end
		e:startServer(); e:step(.1)
		underlying = e.stores[name]
		return e, a, underlying, name
	end
	-- Only the drain's own report; the start-up "ACCEPTANCE DataStore namespace"
	-- line also contains no "shutdown", but "shutdown •" is unambiguous.
	local function shutdownLog(e)
		local out = {}
		for _, entry in e.logs do
			if (entry.name == "Log" or entry.name == "Warn") and string.find(entry.text, "shutdown •", 1, true) then
				table.insert(out, entry.text)
			end
		end
		return out
	end

	test("7C-S1: shutdown saves every loaded profile",function()
		local e, a = joinedServer({})
		-- Earn something durable through the real payout path.
		e:step(12.2); eq(e:lastState().phase, "Playing")
		collect(e, a, 2)
		e:step(190)                            -- round closes, payout + save
		local P = e:import("src/server/Persistence.luau")
		local key = P.key(-42)
		local underlying = e.stores["BrainrotArenaAcceptance_p7c-shutdown"]
		local before = underlying[key] and underlying[key].Coins
		assert(before and before > 0, "the payout must be durable before shutdown")
		-- A second, unsaved gain: mutate the live session the way a mid-round
		-- catch does, then shut down without a round boundary.
		local profiles = nil
		eq(e:shutdown(), 1, "the server must register exactly one BindToClose")
		local logs = shutdownLog(e)
		assert(#logs >= 1, "shutdown must log a report")
		-- The record is intact and still carries the earned coins.
		eq(underlying[key].Coins, before)
		assert(string.find(logs[1], "writable", 1, true), "the report names what it flushed")
	end)

	test("7C-S2: shutdown never writes a profile whose load failed",function()
		local seed = seededVeteran()
		local resolved = nil
		local e, a, underlying = joinedServer({ readFail = true }, seed)
		local P = e:import("src/server/Persistence.luau")
		local key = P.key(-42)
		-- The read failed, so the session is Failed and must stay non-writable.
		eq(e:shutdown(), 1)
		local after = underlying[key]
		eq(after.Coins, 5000, "a failed load must survive the shutdown untouched")
		eq(after.Rounds, 120)
		eq(after.Specimens.toast, 9)
		local logs = shutdownLog(e)
		assert(#logs >= 1, "shutdown must report")
		-- zero writable profiles: nothing was flushed for this player
		assert(string.find(logs[1], "0 writable", 1, true),
			"the failed profile must not be counted writable: " .. logs[1])
	end)

	test("7C-S3: shutdown while a save is already running does not duplicate it",function()
		local e, a = joinedServer({})
		local P = e:import("src/server/Persistence.luau")
		local key = P.key(-42)
		local underlying = e.stores["BrainrotArenaAcceptance_p7c-shutdown"]
		-- Leave with a queued write outstanding, then shut down before it lands.
		e:step(12.2); collect(e, a, 1)
		-- A halo purchase queues a save through the gameplay path.
		e:step(190)
		local legacyWrites = e.writeCounts[key] or 0
		e:shutdown()
		local afterShutdown = e.writeCounts[key] or 0
		-- Whatever the timing, a single shutdown must not add more than one
		-- write per player beyond the one that was already running.
		assert(afterShutdown - legacyWrites <= 1,
			string.format("shutdown duplicated a write: %d -> %d", legacyWrites, afterShutdown))
		assert(underlying[key], "the record is still present")
	end)

	test("7C-S4: PlayerRemoving and BindToClose together write once, newest data",function()
		local e, a = joinedServer({})
		local P = e:import("src/server/Persistence.luau")
		local key = P.key(-42)
		local underlying = e.stores["BrainrotArenaAcceptance_p7c-shutdown"]
		e:step(12.2); collect(e, a, 3)
		e:step(190)   -- round closes and pays
		local afterPayout = e.writeCounts[key] or 0
		-- Player leaving triggers PlayerRemoving; the shutdown then runs too.
		e:removePlayer(a)
		e:shutdown()
		local total = e.writeCounts[key] or 0
		-- The unchanged payload must not be rewritten: at most one extra write
		-- (the leave), and certainly not one per entry point.
		assert(total - afterPayout <= 1,
			string.format("duplicate writes on leave+shutdown: %d -> %d", afterPayout, total))
		assert(underlying[key].Coins > 0, "the payout survived")
	end)

	test("7C-S5: a DataStore write failure during shutdown corrupts nothing",function()
		local seed = seededVeteran()
		local e, a, underlying = joinedServer({}, seed)
		local P = e:import("src/server/Persistence.luau")
		local key = P.key(-42)
		eq(underlying[key].Coins, 5000)
		-- Fail every write from here on: the shutdown must give up cleanly.
		e.options.writeFail = true
		e:shutdown()
		-- The previous record is byte-for-byte intact; a failed write must not
		-- have replaced it with a default or a partial table.
		eq(underlying[key].Coins, 5000)
		eq(underlying[key].Rounds, 120)
		eq(underlying[key].Specimens.toast, 9)
		local logs = shutdownLog(e)
		assert(#logs >= 1)
		local warned = false
		for _, entry in e.logs do
			if entry.name == "Warn" and string.find(entry.text, "shutdown finished with", 1, true) then
				warned = true
			end
		end
		assert(warned, "a failed shutdown save must be reported, not swallowed")
	end)

	test("7C-S6: multiple players all save during one shutdown",function()
		local e, name = shutdownFixture({})
		local a = e:addPlayer(-42, "One")
		local b = e:addPlayer(-43, "Two")
		local c = e:addPlayer(-44, "Three")
		e:startServer(); e:step(.1)
		local underlying = e.stores[name]
		eq(e:shutdown(), 1)
		local P = e:import("src/server/Persistence.luau")
		for _, id in { -42, -43, -44 } do
			local key = P.key(id)
			assert(underlying[key] ~= nil, "player " .. id .. " was not saved by the shutdown")
		end
		local logs = shutdownLog(e)
		assert(#logs >= 1)
		assert(string.find(logs[1], "3 writable", 1, true),
			"all three must be counted writable: " .. logs[1])
	end)

	test("7C-S7: a leaving player's final save is not dropped by release",function()
		-- Regression for a real data-loss bug: PlayerRemoving used to QUEUE the
		-- final save and then immediately call release(), which bumps the
		-- generation. The queued write then saw a newer generation and aborted,
		-- so every leaving player's last session was silently lost. Proven on
		-- the pre-fix source, where the store was still empty after the flush.
		local e, a = joinedServer({})
		local P = e:import("src/server/Persistence.luau")
		local key = P.key(-42)
		local underlying = e.stores["BrainrotArenaAcceptance_p7c-shutdown"]
		e:step(12.2); collect(e, a, 2)
		e:step(190)
		assert(underlying[key], "the round payout is durable")
		local coins = underlying[key].Coins
		-- Leave and let the removal save complete.
		e:removePlayer(a); e:step(.5)
		assert(underlying[key], "the leave save must reach the store")
		eq(underlying[key].Coins, coins, "and it must be the same record")
	end)

	test("7C-S8: shutdown is idempotent and bounded",function()
		local e, name = shutdownFixture({})
		e:addPlayer(-42, "One")
		e:startServer(); e:step(.1)
		eq(e:shutdown(), 1)
		-- A second bind (or a re-entrant drain) must not write again.
		local underlying = e.stores[name]
		local P = e:import("src/server/Persistence.luau")
		local key = P.key(-42)
		local writes = e.writeCounts[key] or 0
		local profiles = nil
		e:shutdown()   -- no bindings left
		eq(e.writeCounts[key] or 0, writes, "a second shutdown must not rewrite")
		assert(underlying[key], "the record is present")
	end)

	-- ------------------------------------------------------------------------ #
	-- PHASE 7C: the bottom control row, measured as real rectangles.
	--
	-- Three controls share the bottom of the screen: the steal panel (with its
	-- readout riding 38 px above it), the ability panel, and the shop bar. Before
	-- this phase all three were placed independently in the same band and
	-- overlapped at EVERY phone size (390x800 included). These tests measure the
	-- union footprint, not just the button rects, because the readout is what the
	-- bar was actually sitting on.
	-- ------------------------------------------------------------------------ #
	local function footprint(e)
		-- {name, rect} for each control, with the steal readout folded in.
		local steal = e:find("StealPanel")
		local readout = steal:FindFirstChild("Carried", true)
		local s = rect(steal)
		local box = { x = s.x, y = s.y, w = s.w, h = s.h }
		if readout and readout.Visible then
			local r = rect(readout)
			local top = math.min(box.y, r.y)
			local bottom = math.max(box.y + box.h, r.y + r.h)
			box = { x = math.min(box.x, r.x), y = top, w = math.max(box.w, r.w), h = bottom - top }
		end
		return {
			{ name = "steal(+readout)", rect = box },
			{ name = "ability", rect = rect(e:find("AbilityPanel")) },
			{ name = "actionbar", rect = rect(e:find("ActionBar")) },
		}
	end

	-- The full matrix required by the phase, plus the shapes around the
	-- two-row / single-row boundary (700 px) so an off-by-one cannot hide.
	local CONTROL_VIEWPORTS = {
		{ 320, 568 }, { 360, 740 }, { 390, 800 }, { 430, 900 },   -- portrait phones
		{ 412, 915 }, { 844, 354 }, { 740, 360 }, { 932, 430 },   -- landscape phones
		{ 600, 400 }, { 699, 500 }, { 700, 500 },                 -- row-boundary cases
		{ 768, 1024 }, { 820, 1180 }, { 1024, 768 },              -- tablets
		{ 1280, 720 }, { 1280, 600 }, { 1920, 1080 },             -- desktop
	}

	test("7C-S9: shutdown in Studio is honest about memory-only",function()
		-- Studio opens no DataStore, so a shutdown can write nothing. The report
		-- must say memoryOnly=true and must not claim a write: a green shutdown
		-- line in Studio is not evidence of persistence.
		local e = Mock.new(sources, schema, { fast = true, studio = true })
		e:addPlayer(-1, "StudioPlayer")
		e:startServer(); e:step(.1)
		local opened = 0
		for _ in pairs(e.stores) do opened += 1 end
		eq(opened, 0, "Studio must open no DataStore")
		eq(#e.closeBindings, 1, "the shutdown binding must still be registered")
		e:shutdown()
		local logs = shutdownLog(e)
		assert(#logs >= 1, "shutdown must report")
		assert(string.find(logs[1], "memoryOnly=true", 1, true), "the report must name memory-only: " .. logs[1])
		assert(string.find(logs[1], "0 written", 1, true), "nothing may be claimed as written: " .. logs[1])
	end)

	test("7C-S10: the shutdown report counts writes truthfully",function()
		-- The report is the only evidence a live operator gets from a shutdown,
		-- so it must not over-count. Three cases, exact numbers.
		local function report(options)
			local e, name = shutdownFixture(options)
			e:addPlayer(-42, "A"); e:addPlayer(-43, "B")
			e:startServer(); e:step(.1)
			if options and options.writeFail then e.options.writeFail = true end
			e:shutdown()
			local logs = shutdownLog(e)
			assert(#logs == 1, "exactly one shutdown report")
			return logs[1]
		end
		local ok = report({})
		assert(string.find(ok, "2 writable", 1, true) and string.find(ok, "2 written", 1, true),
			"both fresh players must be written: " .. ok)
		local failed = report({ writeFail = true })
		assert(string.find(failed, "0 written", 1, true) and string.find(failed, "2 failed", 1, true),
			"a failed write must not be counted as written: " .. failed)
		local unread = report({ readFail = true })
		assert(string.find(unread, "0 writable", 1, true),
			"an unreadable profile is not writable: " .. unread)
	end)

	test("7C-M1: no bottom control overlaps another at any viewport",function()
		for _,size in CONTROL_VIEWPORTS do
			local e=fixture(nil,true); e:setViewport(size[1],size[2])
			local boxes=footprint(e)
			for i=1,#boxes do
				for j=i+1,#boxes do
					local a,b=boxes[i],boxes[j]
					assert(not overlaps(a.rect,b.rect),string.format(
						"%s overlaps %s at %dx%d: (%.0f,%.0f %.0fx%.0f) / (%.0f,%.0f %.0fx%.0f)",
						a.name,b.name,size[1],size[2],
						a.rect.x,a.rect.y,a.rect.w,a.rect.h,b.rect.x,b.rect.y,b.rect.w,b.rect.h))
				end
			end
		end
	end)

	test("7C-M2: every bottom control stays fully on screen",function()
		for _,size in CONTROL_VIEWPORTS do
			local e=fixture(nil,true); e:setViewport(size[1],size[2])
			for _,box in footprint(e) do
				local r=box.rect
				assert(r.x>=-0.5 and r.y>=-0.5 and r.x+r.w<=size[1]+1 and r.y+r.h<=size[2]+1,
					string.format("%s off screen at %dx%d -> %.0f,%.0f %.0fx%.0f",
						box.name,size[1],size[2],r.x,r.y,r.w,r.h))
			end
		end
	end)

	test("7C-M3: touch targets keep their usable height",function()
		-- 44 px is the accessibility floor the project already uses. Every action
		-- control must clear it at every viewport: a control that fits the screen
		-- but is 20 px tall is not usable on a phone.
		for _,size in CONTROL_VIEWPORTS do
			local e=fixture(nil,true); e:setViewport(size[1],size[2])
			for _,name in {"StealPanel","AbilityPanel","ActionBar"} do
				local r=rect(e:find(name))
				assert(r.h>=44,string.format("%s is only %.0f px tall at %dx%d",name,r.h,size[1],size[2]))
				assert(r.w>=44,string.format("%s is only %.0f px wide at %dx%d",name,r.w,size[1],size[2]))
			end
		end
	end)

	test("7C-M4: mobile controls clear the thumbstick and jump zones",function()
		-- The bottom-right ~110x105 rectangle is where Roblox puts jump, and the
		-- bottom-left is the thumbstick. A control there would fight the player.
		for _,size in {{390,800},{320,568},{844,354},{768,1024}} do
			local e=fixture(nil,true); e:setViewport(size[1],size[2])
			local jump={x=size[1]-110,y=size[2]-105,w=110,h=105}
			local thumb={x=0,y=size[2]-105,w=110,h=105}
			for _,box in footprint(e) do
				assert(not overlaps(box.rect,jump),
					string.format("%s sits on the jump zone at %dx%d",box.name,size[1],size[2]))
				assert(not overlaps(box.rect,thumb),
					string.format("%s sits on the thumbstick at %dx%d",box.name,size[1],size[2]))
			end
		end
	end)

	test("7C-M5: the bar only moves to its own row when one row cannot fit",function()
		-- Guards the layout DECISION through its observable result. On a narrow
		-- phone the bar must sit ABOVE the steal/ability row; on a wide screen it
		-- must share the bottom row (pushing it up there would waste play space).
		local function barIsOnOwnRow(e)
			local bar = rect(e:find("ActionBar"))
			local steal = rect(e:find("StealPanel"))
			-- One row means their vertical spans intersect.
			return bar.y + bar.h <= steal.y + 0.5
		end
		for _,size in {{320,568},{360,740},{390,800},{430,900},{412,915}} do
			local e=fixture(nil,true); e:setViewport(size[1],size[2])
			assert(barIsOnOwnRow(e),string.format("a %d px phone must use two rows",size[1]))
		end
		for _,size in {{1280,720},{1024,768},{1920,1080},{820,1180}} do
			local e=fixture(nil,true); e:setViewport(size[1],size[2])
			assert(not barIsOnOwnRow(e),string.format("%dx%d has room for one row",size[1],size[2]))
		end
	end)

	test("7C-M6: rotating between the two layouts keeps every control on screen",function()
		-- `resize()` runs on every AbsoluteSize change, and the layout switches
		-- between one row and two as the width crosses the threshold. A control
		-- that kept a stale anchor across that switch would be stranded.
		local e=fixture(nil,true)
		for _,size in {{390,800},{1280,720},{844,354},{390,800},{820,1180},{699,500},{700,500}} do
			e:setViewport(size[1],size[2])
			local boxes=footprint(e)
			for i=1,#boxes do
				local r=boxes[i].rect
				assert(r.x>=-0.5 and r.y>=-0.5 and r.x+r.w<=size[1]+1 and r.y+r.h<=size[2]+1,
					string.format("%s stranded after rotation to %dx%d -> %.0f,%.0f",
						boxes[i].name,size[1],size[2],r.x,r.y))
				for j=i+1,#boxes do
					assert(not overlaps(boxes[i].rect,boxes[j].rect),
						string.format("%s/%s overlap after rotation to %dx%d",
							boxes[i].name,boxes[j].name,size[1],size[2]))
				end
			end
		end
	end)

	print(string.format("\nADAPTER RESULTS: %d passed, %d failed (mock Roblox boundary, no engine physics)",passed,failed))
	assert(failed==0,"Adapter test failures")
end
